# 🦁 Arslan — Yapay Zeka Asistan

**Arslan**, Groq (Whisper + LLaMA) tabanlı, tamamen Türkçe, sesli ve klavyeli çalışan bir masaüstü yapay zeka asistanıdır.

> Windows · Linux · macOS üzerinde çalışır.

---

## ✨ Özellikler

| Kategori | Neler yapabilir? |
|---|---|
| 🎙️ Ses | Wake word (`Arslan`), push-to-talk, Türkçe TTS |
| 📁 Dosya | Oluştur, sil, listele, taşı, kopyala, ara, fuzzy match |
| 🖥️ Sistem | Ses, parlaklık, pil, CPU/RAM, WiFi, ekran görüntüsü |
| 🚀 Uygulama | Aç, kapat (Windows/Linux/macOS) |
| ⏱️ Zamanlama | Zamanlayıcı, alarm, hatırlatıcı |
| 🌤️ Bilgi | Hava durumu (wttr.in), haberler (RSS) |
| 🧮 Hesap | Güvenli AST tabanlı hesap makinesi, birim dönüşümü |
| 📝 Not | Not al, listele, ara |
| 📧 E-posta | IMAP okuma, SMTP gönderme |
| 🎵 Medya | YouTube ara, oynat/durdur/ileri/geri |

---

## ⚡ Hızlı Kurulum

### 1. Repoyu klonla
```bash
git clone https://github.com/KULLANICIN/arslan.git
cd arslan
```

### 2. Bağımlılıkları kur
```bash
pip install -r requirements.txt

# Yalnızca Windows'ta:
pip install -r requirements-windows.txt
```

> **PyAudio kurulum sorunu yaşıyorsanız:**
> - Windows: `pip install pipwin && pipwin install pyaudio`
> - Linux: `sudo apt install portaudio19-dev && pip install pyaudio`
> - macOS: `brew install portaudio && pip install pyaudio`

### 3. API anahtarını ayarla
```bash
cp .env.example .env
# .env dosyasını açıp GROQ_API_KEY değerini girin
```

> Groq API ücretsizdir: https://console.groq.com/keys

### 4. Çalıştır
```bash
# Sesli mod (mikrofon gerektirir)
python arslan.py

# Klavye modu (mikrofon gerekmez)
python arslan.py --klavye

# Ses + klavye karışık mod
python arslan.py --karistik

# Tek komut çalıştır
python arslan.py --komut "saat kaç"
```

---

## 🗂️ Proje Yapısı

```
arslan/
├── arslan.py              # Ana program
├── requirements.txt       # Genel bağımlılıklar
├── requirements-windows.txt # Windows-only bağımlılıklar
├── .env.example           # Örnek ortam değişkenleri
├── .gitignore             # Gizli dosyalar hariç
└── README.md
```

---

## 🔒 Güvenlik

- API anahtarlarınız **asla** kodda bulunmaz, `.env` dosyasından okunur
- `.env` dosyası `.gitignore` ile korunur, GitHub'a yüklenmez
- E-posta şifreleri **veritabanına kaydedilmez**, sadece `.env`'den okunur
- Hesap makinesi `eval()` yerine **güvenli AST** tabanlı değerlendirici kullanır
- Kişisel veriler (`arslan_data/`) `.gitignore` ile korunur

---

## 🎤 Kullanım Örnekleri

```
Arslan → "Belgeler klasörünü aç"
Arslan → "5 dakika zamanlayıcı kur"
Arslan → "Sesi yüzde 40 yap"
Arslan → "İstanbul hava durumu nasıl"
Arslan → "YouTube'da lo-fi müzik çal"
Arslan → "CPU kullanımı ne kadar"
Arslan → "25 çarpı 4 hesapla"
Arslan → "Toplantı notu al: Pazartesi saat 10 sunum var"
Arslan → "Chrome'u aç"
Arslan → "Ekran görüntüsü al"
```

---

## ⚙️ Konfigürasyon

`.env` dosyasındaki ayarlar:

| Değişken | Açıklama | Varsayılan |
|---|---|---|
| `GROQ_API_KEY` | Groq API anahtarı (zorunlu) | — |
| `ARSLAN_NAME` | Asistan adı / wake word | `Arslan` |
| `ARSLAN_OWNER` | Kullanıcı adı | `Orhan` |
| `TTS_VOICE` | TTS sesi | `tr-TR-AhmetNeural` |
| `TTS_RATE` | Konuşma hızı | `+30%` |
| `EMAIL_ADDRESS` | E-posta adresi | — |
| `EMAIL_PASSWORD` | E-posta şifresi (App Password) | — |

---

## 🤝 Katkı

Pull request ve issue'lar memnuniyetle kabul edilir.

---

## 📄 Lisans

MIT License — Dilediğiniz gibi kullanabilirsiniz.
