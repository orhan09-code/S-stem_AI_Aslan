"""
╔══════════════════════════════════════════════════════════════════════════════════╗
║                    ARSLAN - GELİŞMİŞ YAPAY ZEKA ASİSTAN SİSTEMİ                ║
║                         Geliştiren: Orhan için Arslan v3.1                      ║
║                                                                                  ║
║  Özellikler:                                                                     ║
║  • Sesli komut & uyandırma sistemi (push-to-talk + wake word)                   ║
║  • Dosya & Klasör yönetimi (oluştur/sil/tara/listele/taşı/kopyala)             ║
║  • Akıllı fuzzy matching (bitki klasörü → Bitkiler, Botanik vb.)               ║
║  • Sistem kontrolü (ses, parlaklık, wifi, bluetooth, güç)                       ║
║  • Uygulama başlatma & kapatma                                                  ║
║  • Tarayıcı kontrolü (arama, sekme açma/kapatma)                               ║
║  • Pano yönetimi (kopyala/yapıştır)                                             ║
║  • Ekran görüntüsü alma                                                         ║
║  • Sistem bilgisi (CPU, RAM, disk, pil)                                         ║
║  • Hava durumu                                                                  ║
║  • Haber okuma                                                                  ║
║  • Zamanlayıcı & alarm kurma                                                    ║
║  • Hesap makinesi (güvenli)                                                     ║
║  • Not alma & hatırlatıcı                                                       ║
║  • Medya kontrolü                                                               ║
║  • E-posta okuma & gönderme                                                     ║
║  • Takvim & randevu                                                             ║
║  • PDF okuma & özetleme                                                         ║
║  • Cross-platform destek (Windows/Linux/macOS)                                  ║
║  • Konuşma geçmişi & uzun süreli hafıza                                        ║
╚══════════════════════════════════════════════════════════════════════════════════╝
"""

# ═══════════════════════════════════════════════════════════════
# BÖLÜM 1: KÜTÜPHANELER VE BAĞIMLILIKLAR
# ═══════════════════════════════════════════════════════════════

import os
import sys
import wave
import time
import json
import math
import shutil
import socket
import struct
import string
import hashlib
import logging
import platform
import threading
import subprocess
import webbrowser
import asyncio
import re
import gc
import glob
import difflib
import calendar
import random
import tempfile
import zipfile
import smtplib
import imaplib
import email
import email.mime.text
import email.mime.multipart
import urllib.request
import urllib.parse
import http.client
import datetime
import traceback
import textwrap
import unicodedata
import base64
import io
import queue
import signal
import atexit
import sqlite3
import xml.etree.ElementTree as ET
import ast
import operator

from pathlib import Path
from collections import defaultdict, deque
from email.header import decode_header
from threading import Timer, Event, Lock
from typing import Optional, List, Dict, Any, Tuple, Callable
from dataclasses import dataclass, field, asdict
from functools import wraps, lru_cache
from contextlib import contextmanager

# ── Ortam değişkeni yükleyici (.env desteği) ──────────────────
def _env_yukle(env_dosyasi: str = ".env"):
    """Basit .env dosyası yükleyici (python-dotenv gerektirmez)."""
    env_yolu = Path(env_dosyasi)
    if not env_yolu.exists():
        # Bir üst dizinde de ara
        env_yolu = Path(__file__).parent / ".env"
    if env_yolu.exists():
        with open(env_yolu, encoding="utf-8") as f:
            for satir in f:
                satir = satir.strip()
                if satir and not satir.startswith("#") and "=" in satir:
                    anahtar, deger = satir.split("=", 1)
                    anahtar = anahtar.strip()
                    deger = deger.strip().strip('"').strip("'")
                    if anahtar not in os.environ:  # Mevcut değerleri ezmez
                        os.environ[anahtar] = deger

_env_yukle()

# ── Platform tespiti ───────────────────────────────────────────
PLATFORM = platform.system()  # "Windows", "Linux", "Darwin"
IS_WINDOWS = PLATFORM == "Windows"
IS_LINUX   = PLATFORM == "Linux"
IS_MAC     = PLATFORM == "Darwin"

# ── Windows-only importlar ────────────────────────────────────
if IS_WINDOWS:
    try:
        import ctypes
        import winreg
        CTYPES_OK  = True
        WINREG_OK  = True
    except ImportError:
        CTYPES_OK  = False
        WINREG_OK  = False
else:
    CTYPES_OK  = False
    WINREG_OK  = False

# ── Üçüncü taraf kütüphaneler (opsiyonel) ─────────────────────
try:
    import pyaudio
    PYAUDIO_OK = True
except ImportError:
    PYAUDIO_OK = False

try:
    import numpy as np
    NUMPY_OK = True
except ImportError:
    NUMPY_OK = False

try:
    import edge_tts
    EDGE_TTS_OK = True
except ImportError:
    EDGE_TTS_OK = False

try:
    import pygame
    PYGAME_OK = True
except ImportError:
    PYGAME_OK = False

try:
    from groq import Groq
    GROQ_OK = True
except ImportError:
    GROQ_OK = False

try:
    import psutil
    PSUTIL_OK = True
except ImportError:
    PSUTIL_OK = False

try:
    import pyperclip
    PYPERCLIP_OK = True
except ImportError:
    PYPERCLIP_OK = False

try:
    import pyautogui
    PYAUTOGUI_OK = True
except ImportError:
    PYAUTOGUI_OK = False

try:
    from PIL import ImageGrab, Image
    PIL_OK = True
except ImportError:
    PIL_OK = False

try:
    import requests
    REQUESTS_OK = True
except ImportError:
    REQUESTS_OK = False

try:
    import pdfplumber
    PDF_OK = True
except ImportError:
    PDF_OK = False

# Windows ses kontrolü
PYCAW_OK = False
if IS_WINDOWS:
    try:
        from comtypes import CLSCTX_ALL
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
        PYCAW_OK = True
    except ImportError:
        pass

# Parlaklık kontrolü
try:
    import screen_brightness_control as sbc
    SBC_OK = True
except ImportError:
    SBC_OK = False

# ═══════════════════════════════════════════════════════════════
# BÖLÜM 2: YAPILANDIRMA VE SABİTLER
# ═══════════════════════════════════════════════════════════════

VERSION        = "3.1.0"
BUILD_DATE     = "2025"
ASSISTANT_NAME = os.environ.get("ARSLAN_NAME", "Arslan")
OWNER_NAME     = os.environ.get("ARSLAN_OWNER", "Orhan")

# ── Yollar ────────────────────────────────────────────────────
BASE_DIR       = Path(__file__).parent.resolve()
DATA_DIR       = BASE_DIR / "arslan_data"
LOG_DIR        = DATA_DIR / "logs"
NOTES_DIR      = DATA_DIR / "notlar"
MEMORY_DIR     = DATA_DIR / "hafiza"
SCREENSHOT_DIR = DATA_DIR / "ekran_goruntuleri"
TEMP_DIR       = DATA_DIR / "temp"
PROFILE_DIR    = DATA_DIR / "profil"

for _d in [DATA_DIR, LOG_DIR, NOTES_DIR, MEMORY_DIR, SCREENSHOT_DIR, TEMP_DIR, PROFILE_DIR]:
    _d.mkdir(parents=True, exist_ok=True)

# ── Platform'a göre kullanıcı dizinleri ───────────────────────
USERPROFILE      = Path.home()
DESKTOP_PATH     = USERPROFILE / "Desktop"
DOCUMENTS_PATH   = USERPROFILE / "Documents"
DOWNLOADS_PATH   = USERPROFILE / "Downloads"
PICTURES_PATH    = USERPROFILE / "Pictures"
MUSIC_PATH       = USERPROFILE / "Music"
VIDEOS_PATH      = USERPROFILE / "Videos"

if IS_WINDOWS:
    APPDATA_PATH      = Path(os.environ.get("APPDATA",      str(USERPROFILE / "AppData/Roaming")))
    LOCALAPPDATA_PATH = Path(os.environ.get("LOCALAPPDATA", str(USERPROFILE / "AppData/Local")))
elif IS_MAC:
    APPDATA_PATH      = USERPROFILE / "Library/Application Support"
    LOCALAPPDATA_PATH = APPDATA_PATH
else:
    APPDATA_PATH      = USERPROFILE / ".config"
    LOCALAPPDATA_PATH = USERPROFILE / ".local/share"

# ── API Anahtarları (.env veya ortam değişkeninden) ───────────
GROQ_API_KEY    = os.environ.get("GROQ_API_KEY", "")
WEATHER_API_KEY = os.environ.get("WEATHER_API_KEY", "")
NEWS_API_KEY    = os.environ.get("NEWS_API_KEY", "")

if not GROQ_API_KEY:
    print("[UYARI] GROQ_API_KEY bulunamadı. .env dosyasına ekleyin.")

# ── Ses ayarları ───────────────────────────────────────────────
AUDIO_CHUNK    = 1024
AUDIO_RATE     = 44100
AUDIO_CHANNELS = 1

# ── Uyandırma / uyku sözcükleri ───────────────────────────────
WAKE_WORDS = [
    "arslan", "aslan", "arslaan", "arslen", "aslen",
    "hey arslan", "hey aslan", "evet arslan", "tamam arslan"
]

SLEEP_WORDS = [
    "uyu", "kapat", "dinlen", "görüşürüz", "tamam görüşürüz",
    "bitti", "dur", "bekle", "seni istemiyorum"
]

# ── TTS ayarları ───────────────────────────────────────────────
TTS_VOICE  = os.environ.get("TTS_VOICE",  "tr-TR-AhmetNeural")
TTS_RATE   = os.environ.get("TTS_RATE",   "+30%")
TTS_VOLUME = os.environ.get("TTS_VOLUME", "+0%")

# ── Ses & uyandırma parametreleri (optimize edildi) ───────────
# Önceki: WAKE_THRESHOLD=150, WAKE_CHUNKS=100 (~2 saniye kayıt)
# Şimdi:  Eşik düşürüldü, chunk sayısı azaltıldı → ~0.8s gecikme
SILENCE_LIMIT   = 0.6   # saniye (azaltıldı)
WAKE_THRESHOLD  = 120   # ses eşiği (daha duyarlı)
SPEAK_THRESHOLD = 80    # konuşma eşiği
WAKE_CHUNKS     = 40    # ~0.9 saniye kayıt (100'den düşürüldü)
MAX_HISTORY     = 20

# ═══════════════════════════════════════════════════════════════
# BÖLÜM 3: LOGLAMA SİSTEMİ
# ═══════════════════════════════════════════════════════════════

def setup_logger(name: str, log_dir: Path) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    log_file = log_dir / f"{name}_{datetime.datetime.now().strftime('%Y%m%d')}.log"
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.WARNING)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s", datefmt="%H:%M:%S")
    fh.setFormatter(fmt)
    ch.setFormatter(fmt)
    if not logger.handlers:
        logger.addHandler(fh)
        logger.addHandler(ch)
    return logger

log = setup_logger("arslan", LOG_DIR)

# ═══════════════════════════════════════════════════════════════
# BÖLÜM 4: VERİTABANI VE HAFIZA SİSTEMİ
# ═══════════════════════════════════════════════════════════════

class ArslanDatabase:
    """SQLite tabanlı kalıcı hafıza ve veri deposu."""

    def __init__(self, db_path: Path):
        self.db_path = db_path / "arslan_memory.db"
        self.conn    = None
        self.lock    = Lock()
        self._connect()
        self._create_tables()

    def _connect(self):
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")

    def _create_tables(self):
        with self.lock:
            cur = self.conn.cursor()
            cur.executescript("""
                CREATE TABLE IF NOT EXISTS konusmalar (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tarih TEXT NOT NULL,
                    rol TEXT NOT NULL,
                    icerik TEXT NOT NULL,
                    oturum_id TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS hafiza (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    anahtar TEXT UNIQUE NOT NULL,
                    deger TEXT NOT NULL,
                    kategori TEXT DEFAULT 'genel',
                    onem INTEGER DEFAULT 1,
                    guncelleme_tarihi TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS notlar (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    baslik TEXT NOT NULL,
                    icerik TEXT NOT NULL,
                    etiketler TEXT DEFAULT '',
                    olusturma_tarihi TEXT NOT NULL,
                    duzenleme_tarihi TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS hatirlaticilar (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    mesaj TEXT NOT NULL,
                    zaman TEXT NOT NULL,
                    tekrar TEXT DEFAULT 'bir_kez',
                    aktif INTEGER DEFAULT 1,
                    olusturma_tarihi TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS uygulamalar (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    isim TEXT UNIQUE NOT NULL,
                    yol TEXT NOT NULL,
                    takma_adlar TEXT DEFAULT '',
                    kullanim_sayisi INTEGER DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS komut_gecmisi (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    komut TEXT NOT NULL,
                    sonuc TEXT NOT NULL,
                    basarili INTEGER DEFAULT 1,
                    tarih TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS tercihler (
                    anahtar TEXT PRIMARY KEY,
                    deger TEXT NOT NULL
                );
            """)
            self.conn.commit()

    def konusma_ekle(self, rol: str, icerik: str, oturum_id: str):
        with self.lock:
            try:
                self.conn.execute(
                    "INSERT INTO konusmalar (tarih, rol, icerik, oturum_id) VALUES (?, ?, ?, ?)",
                    (datetime.datetime.now().isoformat(), rol, icerik, oturum_id)
                )
                self.conn.commit()
            except Exception as e:
                log.error(f"konusma_ekle: {e}")

    def son_konusmalar(self, limit: int = 20, oturum_id: str = None) -> List[Dict]:
        with self.lock:
            try:
                if oturum_id:
                    rows = self.conn.execute(
                        "SELECT rol, icerik FROM konusmalar WHERE oturum_id=? ORDER BY id DESC LIMIT ?",
                        (oturum_id, limit)
                    ).fetchall()
                else:
                    rows = self.conn.execute(
                        "SELECT rol, icerik FROM konusmalar ORDER BY id DESC LIMIT ?", (limit,)
                    ).fetchall()
                return [{"role": r["rol"], "content": r["icerik"]} for r in reversed(rows)]
            except Exception as e:
                log.error(f"son_konusmalar: {e}")
                return []

    def hafiza_kaydet(self, anahtar: str, deger: str, kategori: str = "genel", onem: int = 1):
        with self.lock:
            try:
                self.conn.execute(
                    """INSERT INTO hafiza (anahtar, deger, kategori, onem, guncelleme_tarihi)
                       VALUES (?, ?, ?, ?, ?)
                       ON CONFLICT(anahtar) DO UPDATE SET
                       deger=excluded.deger, guncelleme_tarihi=excluded.guncelleme_tarihi""",
                    (anahtar, deger, kategori, onem, datetime.datetime.now().isoformat())
                )
                self.conn.commit()
            except Exception as e:
                log.error(f"hafiza_kaydet: {e}")

    def hafiza_oku(self, anahtar: str) -> Optional[str]:
        with self.lock:
            try:
                row = self.conn.execute(
                    "SELECT deger FROM hafiza WHERE anahtar=?", (anahtar,)
                ).fetchone()
                return row["deger"] if row else None
            except Exception as e:
                log.error(f"hafiza_oku: {e}")
                return None

    def not_ekle(self, baslik: str, icerik: str, etiketler: str = "") -> int:
        with self.lock:
            try:
                simdi = datetime.datetime.now().isoformat()
                cur = self.conn.execute(
                    "INSERT INTO notlar (baslik, icerik, etiketler, olusturma_tarihi, duzenleme_tarihi) VALUES (?, ?, ?, ?, ?)",
                    (baslik, icerik, etiketler, simdi, simdi)
                )
                self.conn.commit()
                return cur.lastrowid
            except Exception as e:
                log.error(f"not_ekle: {e}")
                return -1

    def notlari_listele(self, arama: str = None) -> List[Dict]:
        with self.lock:
            try:
                if arama:
                    rows = self.conn.execute(
                        "SELECT * FROM notlar WHERE baslik LIKE ? OR icerik LIKE ? ORDER BY duzenleme_tarihi DESC",
                        (f"%{arama}%", f"%{arama}%")
                    ).fetchall()
                else:
                    rows = self.conn.execute("SELECT * FROM notlar ORDER BY duzenleme_tarihi DESC").fetchall()
                return [dict(r) for r in rows]
            except Exception as e:
                log.error(f"notlari_listele: {e}")
                return []

    def hatirlatici_ekle(self, mesaj: str, zaman: str, tekrar: str = "bir_kez") -> int:
        with self.lock:
            try:
                cur = self.conn.execute(
                    "INSERT INTO hatirlaticilar (mesaj, zaman, tekrar, olusturma_tarihi) VALUES (?, ?, ?, ?)",
                    (mesaj, zaman, tekrar, datetime.datetime.now().isoformat())
                )
                self.conn.commit()
                return cur.lastrowid
            except Exception as e:
                log.error(f"hatirlatici_ekle: {e}")
                return -1

    def aktif_hatirlaticilar(self) -> List[Dict]:
        with self.lock:
            try:
                rows = self.conn.execute(
                    "SELECT * FROM hatirlaticilar WHERE aktif=1 ORDER BY zaman"
                ).fetchall()
                return [dict(r) for r in rows]
            except Exception as e:
                log.error(f"aktif_hatirlaticilar: {e}")
                return []

    def uygulama_ekle(self, isim: str, yol: str, takma_adlar: str = ""):
        with self.lock:
            try:
                self.conn.execute(
                    """INSERT INTO uygulamalar (isim, yol, takma_adlar)
                       VALUES (?, ?, ?)
                       ON CONFLICT(isim) DO UPDATE SET yol=excluded.yol""",
                    (isim, yol, takma_adlar)
                )
                self.conn.commit()
            except Exception as e:
                log.error(f"uygulama_ekle: {e}")

    def uygulama_bul(self, isim: str) -> Optional[str]:
        with self.lock:
            try:
                rows = self.conn.execute("SELECT isim, yol, takma_adlar FROM uygulamalar").fetchall()
                en_iyi = None
                en_iyi_oran = 0
                for row in rows:
                    takma_adlar = [t.strip() for t in row["takma_adlar"].split(",") if t.strip()]
                    oranlar = [difflib.SequenceMatcher(None, isim.lower(), row["isim"].lower()).ratio()]
                    oranlar += [difflib.SequenceMatcher(None, isim.lower(), t.lower()).ratio() for t in takma_adlar]
                    oran = max(oranlar)
                    if oran > en_iyi_oran:
                        en_iyi_oran = oran
                        en_iyi = row["yol"]
                return en_iyi if en_iyi_oran > 0.6 else None
            except Exception as e:
                log.error(f"uygulama_bul: {e}")
                return None

    def komut_kaydet(self, komut: str, sonuc: str, basarili: bool = True):
        with self.lock:
            try:
                self.conn.execute(
                    "INSERT INTO komut_gecmisi (komut, sonuc, basarili, tarih) VALUES (?, ?, ?, ?)",
                    (komut, sonuc, int(basarili), datetime.datetime.now().isoformat())
                )
                self.conn.commit()
            except Exception as e:
                log.error(f"komut_kaydet: {e}")

    def tercih_kaydet(self, anahtar: str, deger: str):
        with self.lock:
            try:
                self.conn.execute(
                    "INSERT OR REPLACE INTO tercihler (anahtar, deger) VALUES (?, ?)",
                    (anahtar, deger)
                )
                self.conn.commit()
            except Exception as e:
                log.error(f"tercih_kaydet: {e}")

    def tercih_oku(self, anahtar: str, varsayilan: str = None) -> Optional[str]:
        with self.lock:
            try:
                row = self.conn.execute(
                    "SELECT deger FROM tercihler WHERE anahtar=?", (anahtar,)
                ).fetchone()
                return row["deger"] if row else varsayilan
            except Exception:
                return varsayilan

    def kapat(self):
        if self.conn:
            self.conn.close()


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 5: FUZZY MATCHING VE AKILLI ANLAMA
# ═══════════════════════════════════════════════════════════════

class AkilliBulucu:
    """Dosya, klasör, uygulama ve komutlar için akıllı fuzzy matching."""

    @staticmethod
    def normalize(metin: str) -> str:
        if not metin:
            return ""
        metin = metin.lower().strip()
        tr_map = str.maketrans("çğışöüÇĞİŞÖÜ", "cgisouCGISOu")  # noqa: RUF001
        return metin.translate(tr_map)

    @staticmethod
    def benzerlik(a: str, b: str) -> float:
        if not a or not b:
            return 0.0
        a_n = AkilliBulucu.normalize(a)
        b_n = AkilliBulucu.normalize(b)
        if a_n == b_n:
            return 1.0
        if a_n in b_n or b_n in a_n:
            return 0.85
        oran = difflib.SequenceMatcher(None, a_n, b_n).ratio()
        tok_a = set(a_n.split())
        tok_b = set(b_n.split())
        if tok_a and tok_b:
            token_oran = len(tok_a & tok_b) / max(len(tok_a), len(tok_b))
            oran = max(oran, token_oran)
        return oran

    @staticmethod
    def en_iyi_eslesme(aranan: str, liste: List[str], esik: float = 0.5) -> Optional[Tuple[str, float]]:
        if not aranan or not liste:
            return None
        en_iyi     = None
        en_iyi_oran = 0.0
        for eleman in liste:
            oran = AkilliBulucu.benzerlik(aranan, eleman)
            if oran > en_iyi_oran:
                en_iyi_oran = oran
                en_iyi      = eleman
        return (en_iyi, en_iyi_oran) if en_iyi and en_iyi_oran >= esik else None

    @staticmethod
    def klasor_bul(aranan: str, baslangic: Path = None, derinlik: int = 3) -> Optional[Path]:
        if baslangic is None:
            baslangic = DESKTOP_PATH
        adaylar = []
        ozel_klasorler = [DESKTOP_PATH, DOCUMENTS_PATH, DOWNLOADS_PATH,
                          PICTURES_PATH, MUSIC_PATH, VIDEOS_PATH]
        # glob tabanlı arama
        try:
            for i in range(derinlik):
                pattern = str(baslangic) + "/*" * (i + 1)
                for yol_str in glob.glob(pattern):
                    yol = Path(yol_str)
                    if yol.is_dir():
                        oran = AkilliBulucu.benzerlik(aranan, yol.name)
                        if oran > 0.4:
                            adaylar.append((yol, oran))
        except Exception:
            pass
        # Özel klasörler
        for okl in ozel_klasorler:
            if okl.exists():
                oran = AkilliBulucu.benzerlik(aranan, okl.name)
                if oran > 0.4:
                    adaylar.append((okl, oran))
                try:
                    for alt in okl.iterdir():
                        if alt.is_dir():
                            oran = AkilliBulucu.benzerlik(aranan, alt.name)
                            if oran > 0.4:
                                adaylar.append((alt, oran))
                except Exception:
                    pass
        if not adaylar:
            return None
        adaylar.sort(key=lambda x: x[1], reverse=True)
        en_iyi_yol, en_iyi_oran = adaylar[0]
        return en_iyi_yol if en_iyi_oran >= 0.45 else None

    @staticmethod
    def dosya_bul(aranan: str, klasor: Path = None, uzanti: str = None) -> Optional[Path]:
        if klasor is None:
            klasor = DESKTOP_PATH
        adaylar = []
        try:
            pattern = f"**/*.{uzanti}" if uzanti else "**/*"
            for dosya in klasor.glob(pattern):
                if dosya.is_file():
                    oran = AkilliBulucu.benzerlik(aranan, dosya.stem)
                    if oran > 0.4:
                        adaylar.append((dosya, oran))
        except Exception as e:
            log.error(f"dosya_bul: {e}")
        if not adaylar:
            return None
        adaylar.sort(key=lambda x: x[1], reverse=True)
        en_iyi_yol, en_iyi_oran = adaylar[0]
        return en_iyi_yol if en_iyi_oran >= 0.45 else None

    @staticmethod
    def benzer_onerileri(aranan: str, liste: List[str], sayi: int = 3) -> List[str]:
        if not aranan or not liste:
            return []
        skorlar = [(e, AkilliBulucu.benzerlik(aranan, e)) for e in liste]
        skorlar.sort(key=lambda x: x[1], reverse=True)
        return [e for e, s in skorlar[:sayi] if s > 0.3]

    @staticmethod
    def komut_anlat(metin: str) -> Dict[str, Any]:
        m = AkilliBulucu.normalize(metin)
        return {
            "ham":               metin,
            "normalize":         m,
            "kelimeler":         m.split(),
            "dosya_mi":          any(k in m for k in ["dosya", "file", "belge", "txt", "pdf", "doc"]),
            "klasor_mu":         any(k in m for k in ["klasor", "klasör", "folder", "dizin"]),
            "sil_mi":            any(k in m for k in ["sil", "kaldir", "delete", "remove", "temizle"]),
            "olustur_mu":        any(k in m for k in ["olustur", "yarat", "create", "yeni"]),
            "listele_mi":        any(k in m for k in ["listele", "goster", "list", "neler", "ne var", "icindekiler"]),
            "ac_mi":             any(k in m for k in ["ac", "open", "baslat", "calistir"]),
            "kapat_mi":          any(k in m for k in ["kapat", "close", "durdur", "sonlandir"]),
            "ara_mi":            any(k in m for k in ["ara", "bul", "search", "find", "nerede"]),
            "kopyala_mi":        any(k in m for k in ["kopyala", "copy", "cogalt"]),
            "tasi_mi":           any(k in m for k in ["tasi", "move", "transfer"]),
        }


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 6: SES ÇIKIŞI (TTS)
# ═══════════════════════════════════════════════════════════════

class SesCikis:
    """Edge TTS + pygame tabanlı ses çıkış sistemi."""

    def __init__(self, ses: str = TTS_VOICE, hiz: str = TTS_RATE, ses_seviyesi: str = TTS_VOLUME):
        self.ses         = ses
        self.hiz         = hiz
        self.ses_seviyesi = ses_seviyesi
        self.susturuldu  = False
        self.kilitli     = Lock()
        self._pygame_hazirla()

    def _pygame_hazirla(self):
        if PYGAME_OK:
            try:
                pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
            except Exception as e:
                log.warning(f"pygame başlatılamadı: {e}")

    def konus(self, metin: str, bekle: bool = True):
        if not metin:
            return
        print(f"\n[{ASSISTANT_NAME}]: {metin}")
        if self.susturuldu or not EDGE_TTS_OK or not PYGAME_OK:
            return
        try:
            with self.kilitli:
                output = str(TEMP_DIR / f"arslan_ses_{int(time.time()*1000)}.mp3")

                async def _gen():
                    comm = edge_tts.Communicate(metin, self.ses, rate=self.hiz, volume=self.ses_seviyesi)
                    await comm.save(output)

                asyncio.run(_gen())

                if not os.path.exists(output):
                    return
                try:
                    pygame.mixer.music.load(output)
                    pygame.mixer.music.play()
                    if bekle:
                        while pygame.mixer.music.get_busy():
                            time.sleep(0.02)
                    pygame.mixer.music.unload()
                except Exception as e:
                    log.error(f"pygame oynatma: {e}")
                finally:
                    try:
                        os.remove(output)
                    except Exception:
                        pass
        except Exception as e:
            log.error(f"TTS: {e}")

    def sustur(self):
        self.susturuldu = True
        if PYGAME_OK:
            try:
                pygame.mixer.music.stop()
            except Exception:
                pass

    def sesi_ac(self):
        self.susturuldu = False


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 7: SES GİRİŞİ VE UYANDIRMA (OPTİMİZE)
# ═══════════════════════════════════════════════════════════════

class SesGiris:
    """
    Optimize edilmiş ses girişi.
    Değişiklikler:
      - WAKE_CHUNKS 100 → 40  (~0.9s kayıt, önceki ~2.2s)
      - Akış yeniden kullanımı (her seferinde aç/kapat yerine)
      - Sessizlik tespiti daha hassas
    """

    def __init__(self, groq_client):
        self.groq     = groq_client
        self.chunk    = AUDIO_CHUNK
        self.rate     = AUDIO_RATE
        self.channels = AUDIO_CHANNELS
        self._pa      = None
        self._stream  = None
        self._stream_lock = Lock()

    def _pa_ac(self):
        if not PYAUDIO_OK:
            return None
        if self._pa is None:
            try:
                self._pa = pyaudio.PyAudio()
            except Exception as e:
                log.error(f"PyAudio açılamadı: {e}")
        return self._pa

    def _stream_al(self):
        """Tek bir stream'i sürekli yeniden kullan."""
        with self._stream_lock:
            pa = self._pa_ac()
            if not pa:
                return None
            if self._stream is None:
                try:
                    self._stream = pa.open(
                        format=pyaudio.paInt16,
                        channels=1,
                        rate=self.rate,
                        input=True,
                        frames_per_buffer=self.chunk
                    )
                except Exception as e:
                    log.error(f"Stream açılamadı: {e}")
                    return None
        return self._stream

    def _stream_kapat(self):
        with self._stream_lock:
            if self._stream:
                try:
                    self._stream.stop_stream()
                    self._stream.close()
                except Exception:
                    pass
                self._stream = None

    def _ses_seviyesi(self, data: bytes) -> float:
        if NUMPY_OK:
            return float(np.abs(np.frombuffer(data, dtype=np.int16)).mean())
        arr = struct.unpack(f"{len(data)//2}h", data)
        return sum(abs(x) for x in arr) / len(arr) if arr else 0.0

    def _transkript_al(self, dosya_yolu: str, dil: str = "tr") -> str:
        if not GROQ_OK or not self.groq:
            return ""
        try:
            with open(dosya_yolu, "rb") as f:
                result = self.groq.audio.transcriptions.create(
                    file=(os.path.basename(dosya_yolu), f.read()),
                    model="whisper-large-v3",
                    language=dil,
                    temperature=0.0
                )
            text = result.text.strip()
            # Sahte Whisper çıktılarını filtrele
            sahte = ["altyazı", "subtitle", "teşekkürler", "thanks for watching",
                     "abone ol", "subscribe", "[müzik]", "[music]"]
            if any(s in text.lower() for s in sahte):
                return ""
            return text
        except Exception as e:
            log.error(f"Transkript: {e}")
            return ""

    def _wav_kaydet(self, dosya_yolu: str, frames: list, rate: int = None):
        pa = self._pa_ac()
        rate = rate or self.rate
        try:
            with wave.open(dosya_yolu, "wb") as wf:
                wf.setnchannels(self.channels)
                wf.setsampwidth(pa.get_sample_size(pyaudio.paInt16) if pa else 2)
                wf.setframerate(rate)
                wf.writeframes(b"".join(frames))
        except Exception as e:
            log.error(f"WAV kaydetme: {e}")

    def pusuda_bekle(self) -> bool:
        """
        Wake word bekle.
        Optimizasyon: Ses algılandığında sadece WAKE_CHUNKS kadar kayıt al
        (önceki: 100 chunk ≈ 2.2s → şimdi: 40 chunk ≈ 0.9s)
        """
        if not PYAUDIO_OK or not NUMPY_OK:
            print(f"\n[{ASSISTANT_NAME}] Enter'a basın: ", end="", flush=True)
            input()
            return True

        stream = self._stream_al()
        if not stream:
            return False

        print(f"\n[Dinlemede — '{ASSISTANT_NAME}' deyin]...", end="\r", flush=True)

        while True:
            try:
                data = stream.read(self.chunk, exception_on_overflow=False)
            except Exception:
                time.sleep(0.01)
                self._stream_kapat()
                stream = self._stream_al()
                if not stream:
                    return False
                continue

            amp = self._ses_seviyesi(data)

            if amp > WAKE_THRESHOLD:
                # Kısa kayıt al (optimize: daha az chunk)
                frames = [data]
                for _ in range(WAKE_CHUNKS):
                    try:
                        frames.append(stream.read(self.chunk, exception_on_overflow=False))
                    except Exception:
                        break

                wake_dosya = str(TEMP_DIR / "wake_check.wav")
                self._wav_kaydet(wake_dosya, frames)

                try:
                    text = self._transkript_al(wake_dosya)
                    if text:
                        text_n = text.lower().strip()
                        for ww in WAKE_WORDS:
                            if AkilliBulucu.benzerlik(text_n, ww) > 0.65 or ww in text_n:
                                return True
                except Exception:
                    pass

    def dinle(self, max_sure: float = 8.0, sessizlik_limiti: float = SILENCE_LIMIT) -> str:
        """
        Kullanıcı konuşmasını kaydet ve metne çevir.
        Optimizasyon: Konuşma başlar başlamaz kayıt başlar,
        sessizlik algılandığında hemen keser.
        """
        if not PYAUDIO_OK or not NUMPY_OK:
            print(f"[{OWNER_NAME}]: ", end="", flush=True)
            return input().strip()

        stream = self._stream_al()
        if not stream:
            return ""

        print(f"[{OWNER_NAME} konuşuyor...]", end="\r", flush=True)

        frames           = []
        sessizlik_sayaci = 0
        bas_zaman        = time.time()
        konusuyor        = False
        maks_sessizlik   = int(sessizlik_limiti * self.rate / self.chunk)

        while True:
            try:
                data = stream.read(self.chunk, exception_on_overflow=False)
            except Exception:
                time.sleep(0.01)
                continue

            frames.append(data)
            amp = self._ses_seviyesi(data)

            if amp > SPEAK_THRESHOLD:
                sessizlik_sayaci = 0
                konusuyor        = True
            else:
                sessizlik_sayaci += 1

            if konusuyor and sessizlik_sayaci > maks_sessizlik:
                break
            if time.time() - bas_zaman > max_sure:
                break

        if not frames:
            return ""

        input_dosya = str(TEMP_DIR / "input_speech.wav")
        self._wav_kaydet(input_dosya, frames)
        text = self._transkript_al(input_dosya)
        if text:
            print(f"[{OWNER_NAME}]: {text}          ")
        return text

    def kapat(self):
        self._stream_kapat()
        if self._pa:
            try:
                self._pa.terminate()
                self._pa = None
            except Exception:
                pass


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 8: DOSYA VE KLASÖR YÖNETİMİ
# ═══════════════════════════════════════════════════════════════

class DosyaYoneticisi:
    """Gelişmiş dosya ve klasör yönetim sistemi."""

    def __init__(self, db: ArslanDatabase):
        self.db           = db
        self.aktif_klasor = DESKTOP_PATH
        self.son_yazilan  = ""
        self.son_dosya    = None

    def aktif_klasor_degistir(self, yol: Path):
        if yol and yol.exists() and yol.is_dir():
            self.aktif_klasor = yol
            self.db.hafiza_kaydet("aktif_klasor", str(yol), "sistem")

    def klasor_olustur(self, isim: str, ana_klasor: Path = None) -> Tuple[bool, str]:
        ana = ana_klasor or self.aktif_klasor
        yol = ana / isim
        try:
            yol.mkdir(parents=True, exist_ok=True)
            self.aktif_klasor_degistir(yol)
            return True, str(yol)
        except PermissionError:
            return False, "İzin hatası."
        except Exception as e:
            return False, str(e)

    def klasor_sil(self, yol: Path) -> Tuple[bool, str]:
        try:
            if yol.exists() and yol.is_dir():
                shutil.rmtree(yol)
                if self.aktif_klasor == yol:
                    self.aktif_klasor = yol.parent
                return True, "Klasör silindi."
            return False, "Klasör bulunamadı."
        except Exception as e:
            return False, str(e)

    def klasor_listele(self, yol: Path = None) -> Tuple[List[Dict], List[Dict]]:
        hedef   = yol or self.aktif_klasor
        klasorler = []
        dosyalar  = []
        try:
            for item in hedef.iterdir():
                try:
                    stat = item.stat()
                    info = {
                        "isim":       item.name,
                        "yol":        str(item),
                        "boyut":      stat.st_size,
                        "degistirme": datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                    }
                    if item.is_dir():
                        klasorler.append(info)
                    else:
                        info["uzanti"] = item.suffix.lower()
                        dosyalar.append(info)
                except Exception:
                    pass
        except PermissionError:
            log.warning(f"İzin yok: {hedef}")
        except Exception as e:
            log.error(f"klasor_listele: {e}")
        klasorler.sort(key=lambda x: x["isim"].lower())
        dosyalar.sort(key=lambda x:  x["isim"].lower())
        return klasorler, dosyalar

    def klasor_ac(self, yol: Path) -> bool:
        try:
            if IS_WINDOWS:
                os.startfile(str(yol))
            elif IS_MAC:
                subprocess.Popen(["open", str(yol)])
            else:
                subprocess.Popen(["xdg-open", str(yol)])
            return True
        except Exception as e:
            log.error(f"klasor_ac: {e}")
            return False

    def klasor_ara_akilli(self, aranan: str) -> Optional[Path]:
        sonuc = AkilliBulucu.klasor_bul(aranan, self.aktif_klasor, derinlik=2)
        if sonuc:
            return sonuc
        for kok in [DESKTOP_PATH, DOCUMENTS_PATH, DOWNLOADS_PATH]:
            sonuc = AkilliBulucu.klasor_bul(aranan, kok, derinlik=2)
            if sonuc:
                return sonuc
        return None

    def dosya_olustur(self, isim: str, icerik: str = "", klasor: Path = None) -> Tuple[bool, str]:
        hedef_klasor = klasor or self.aktif_klasor
        yol = hedef_klasor / isim
        try:
            with open(yol, "w", encoding="utf-8") as f:
                f.write(icerik)
            self.son_yazilan = icerik
            self.son_dosya   = yol
            return True, str(yol)
        except Exception as e:
            return False, str(e)

    def dosya_oku(self, yol: Path, maksimum: int = 5000) -> Tuple[bool, str]:
        try:
            if yol.suffix.lower() == ".pdf":
                return self._pdf_oku(yol, maksimum)
            with open(yol, "r", encoding="utf-8", errors="replace") as f:
                return True, f.read(maksimum)
        except Exception as e:
            return False, str(e)

    def _pdf_oku(self, yol: Path, maksimum: int = 3000) -> Tuple[bool, str]:
        if PDF_OK:
            try:
                metin = []
                with pdfplumber.open(str(yol)) as pdf:
                    for sayfa in pdf.pages[:5]:
                        t = sayfa.extract_text()
                        if t:
                            metin.append(t)
                return True, "\n".join(metin)[:maksimum]
            except Exception as e:
                return False, str(e)
        return False, "PDF kütüphanesi yüklü değil."

    def dosya_yaz(self, yol: Path, icerik: str, mod: str = "w") -> Tuple[bool, str]:
        try:
            with open(yol, mod, encoding="utf-8") as f:
                f.write(icerik)
            self.son_yazilan = icerik
            self.son_dosya   = yol
            return True, "Yazıldı."
        except Exception as e:
            return False, str(e)

    def dosya_sil(self, yol: Path) -> Tuple[bool, str]:
        try:
            if yol.exists() and yol.is_file():
                yol.unlink()
                return True, "Dosya silindi."
            return False, "Dosya bulunamadı."
        except Exception as e:
            return False, str(e)

    def dosya_kopyala(self, kaynak: Path, hedef: Path) -> Tuple[bool, str]:
        try:
            shutil.copy2(str(kaynak), str(hedef))
            return True, f"'{kaynak.name}' kopyalandı."
        except Exception as e:
            return False, str(e)

    def dosya_tasi(self, kaynak: Path, hedef: Path) -> Tuple[bool, str]:
        try:
            shutil.move(str(kaynak), str(hedef))
            return True, f"'{kaynak.name}' taşındı."
        except Exception as e:
            return False, str(e)

    def dosya_ara(self, arama: str, klasor: Path = None, uzanti: str = None) -> List[Path]:
        hedef   = klasor or self.aktif_klasor
        sonuclar = []
        try:
            pattern = f"**/*.{uzanti}" if uzanti else "**/*"
            for dosya in hedef.glob(pattern):
                if dosya.is_file():
                    oran = AkilliBulucu.benzerlik(arama, dosya.stem)
                    if oran > 0.5:
                        sonuclar.append((dosya, oran))
                    elif dosya.stat().st_size < 1_000_000:
                        try:
                            with open(dosya, "r", encoding="utf-8", errors="ignore") as f:
                                if arama.lower() in f.read().lower():
                                    sonuclar.append((dosya, 0.6))
                        except Exception:
                            pass
        except Exception as e:
            log.error(f"dosya_ara: {e}")
        sonuclar.sort(key=lambda x: x[1], reverse=True)
        return [s[0] for s in sonuclar[:20]]

    @staticmethod
    def boyut_formatla(boyut: int) -> str:
        for birim in ["B", "KB", "MB", "GB", "TB"]:
            if boyut < 1024.0:
                return f"{boyut:.1f} {birim}"
            boyut /= 1024.0
        return f"{boyut:.1f} PB"


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 9: SİSTEM KONTROLÜ (CROSS-PLATFORM)
# ═══════════════════════════════════════════════════════════════

class SistemKontrol:
    """Cross-platform sistem kontrol fonksiyonları."""

    def __init__(self, db: ArslanDatabase):
        self.db = db
        self._ses_arayuzu = None
        if IS_WINDOWS:
            threading.Thread(target=self._ses_arayuzu_hazirla, daemon=True).start()

    def _ses_arayuzu_hazirla(self):
        if not PYCAW_OK:
            return
        try:
            import pythoncom
            pythoncom.CoInitialize()
            from ctypes import cast, POINTER
            devices  = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            self._ses_arayuzu = cast(interface, POINTER(IAudioEndpointVolume))
        except Exception as e:
            log.warning(f"Ses arayüzü: {e}")

    # ── Ses ─────────────────────────────────────────────────────

    def sistem_sesi_al(self) -> int:
        if IS_WINDOWS and PYCAW_OK and self._ses_arayuzu:
            try:
                return round(self._ses_arayuzu.GetMasterVolumeLevelScalar() * 100)
            except Exception:
                pass
        if IS_LINUX:
            try:
                out = subprocess.check_output(
                    ["amixer", "get", "Master"], text=True, timeout=5
                )
                m = re.search(r"\[(\d+)%\]", out)
                if m:
                    return int(m.group(1))
            except Exception:
                pass
        if IS_MAC:
            try:
                out = subprocess.check_output(
                    ["osascript", "-e", "output volume of (get volume settings)"],
                    text=True, timeout=5
                )
                return int(out.strip())
            except Exception:
                pass
        return -1

    def sistem_sesi_ayarla(self, seviye: int) -> bool:
        seviye = max(0, min(100, seviye))
        if IS_WINDOWS and PYCAW_OK and self._ses_arayuzu:
            try:
                self._ses_arayuzu.SetMasterVolumeLevelScalar(seviye / 100, None)
                return True
            except Exception:
                pass
        if IS_LINUX:
            try:
                subprocess.run(["amixer", "set", "Master", f"{seviye}%"],
                               capture_output=True, timeout=5)
                return True
            except Exception:
                pass
        if IS_MAC:
            try:
                subprocess.run(["osascript", "-e", f"set volume output volume {seviye}"],
                               capture_output=True, timeout=5)
                return True
            except Exception:
                pass
        return False

    def sistem_sessiz_ac_kapat(self) -> bool:
        if IS_WINDOWS and PYCAW_OK and self._ses_arayuzu:
            try:
                mevcut = self._ses_arayuzu.GetMute()
                self._ses_arayuzu.SetMute(not mevcut, None)
                return True
            except Exception:
                pass
        if IS_LINUX:
            try:
                subprocess.run(["amixer", "-D", "pulse", "set", "Master", "toggle"],
                               capture_output=True, timeout=5)
                return True
            except Exception:
                pass
        if IS_MAC:
            try:
                subprocess.run(["osascript", "-e",
                                "set vol (output muted of (get volume settings))\n"
                                "if vol then\n  set volume without output muted\n"
                                "else\n  set volume with output muted\nend if"],
                               capture_output=True, timeout=5)
                return True
            except Exception:
                pass
        return False

    # ── Parlaklık ────────────────────────────────────────────────

    def parlakligi_al(self) -> int:
        if SBC_OK:
            try:
                return sbc.get_brightness()[0]
            except Exception:
                pass
        return -1

    def parlaklik_ayarla(self, seviye: int) -> bool:
        seviye = max(0, min(100, seviye))
        if SBC_OK:
            try:
                sbc.set_brightness(seviye)
                return True
            except Exception:
                pass
        if IS_LINUX:
            try:
                # xrandr fallback
                subprocess.run(["xrandr", "--output", "eDP-1",
                                "--brightness", str(seviye / 100)],
                               capture_output=True, timeout=5)
                return True
            except Exception:
                pass
        return False

    # ── Pil ─────────────────────────────────────────────────────

    def pil_durumu(self) -> Dict[str, Any]:
        if PSUTIL_OK:
            try:
                pil = psutil.sensors_battery()
                if pil:
                    return {
                        "yuzde":      round(pil.percent),
                        "sarj_oluyor": pil.power_plugged,
                        "kalan_sure": str(datetime.timedelta(seconds=pil.secsleft))
                                       if pil.secsleft and pil.secsleft > 0 else "Bilinmiyor"
                    }
            except Exception:
                pass
        return {"yuzde": -1, "sarj_oluyor": False, "kalan_sure": "Bilinmiyor"}

    # ── CPU / RAM / Disk ─────────────────────────────────────────

    def sistem_bilgisi(self) -> Dict[str, Any]:
        bilgi = {}
        if PSUTIL_OK:
            try:
                bilgi["cpu_yuzde"]    = psutil.cpu_percent(interval=0.5)
                bilgi["cpu_cekirdek"] = psutil.cpu_count()
                ram = psutil.virtual_memory()
                bilgi["ram_toplam"]   = self._boyut_formatla(ram.total)
                bilgi["ram_kullanilan"] = self._boyut_formatla(ram.used)
                bilgi["ram_yuzde"]    = round(ram.percent)
                try:
                    disk_yolu = "C:\\" if IS_WINDOWS else "/"
                    disk = psutil.disk_usage(disk_yolu)
                    bilgi["disk_toplam"]    = self._boyut_formatla(disk.total)
                    bilgi["disk_kullanilan"] = self._boyut_formatla(disk.used)
                    bilgi["disk_yuzde"]     = round(disk.percent)
                except Exception:
                    pass
                bilgi["islemler"] = len(psutil.pids())
            except Exception as e:
                log.error(f"sistem_bilgisi: {e}")
        bilgi["platform"]      = platform.system()
        bilgi["surumu"]        = platform.version()
        bilgi["mimari"]        = platform.machine()
        bilgi["bilgisayar_adi"] = platform.node()
        bilgi["kullanici"]     = os.environ.get("USERNAME", os.environ.get("USER", "Bilinmiyor"))
        return bilgi

    @staticmethod
    def _boyut_formatla(boyut: int) -> str:
        for birim in ["B", "KB", "MB", "GB", "TB"]:
            if boyut < 1024.0:
                return f"{boyut:.1f} {birim}"
            boyut /= 1024.0
        return f"{boyut:.1f} PB"

    def ag_bilgisi(self) -> Dict[str, Any]:
        bilgi = {}
        try:
            bilgi["hostname"] = socket.gethostname()
            bilgi["ip"]       = socket.gethostbyname(socket.gethostname())
        except Exception:
            pass
        if PSUTIL_OK:
            try:
                net = psutil.net_io_counters()
                bilgi["gonderilen"] = self._boyut_formatla(net.bytes_sent)
                bilgi["alinan"]     = self._boyut_formatla(net.bytes_recv)
            except Exception:
                pass
        return bilgi

    def wifi_listele(self) -> List[str]:
        try:
            if IS_WINDOWS:
                out = subprocess.run(
                    ["netsh", "wlan", "show", "networks"],
                    capture_output=True, text=True, encoding="cp1254", timeout=10
                )
                return [a.strip() for a in re.findall(r"SSID\s*:\s*(.+)", out.stdout) if a.strip()]
            elif IS_LINUX:
                out = subprocess.check_output(
                    ["nmcli", "-t", "-f", "SSID", "dev", "wifi"],
                    text=True, timeout=10
                )
                return [l.strip() for l in out.splitlines() if l.strip()]
            elif IS_MAC:
                out = subprocess.check_output(
                    ["/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport",
                     "-s"], text=True, timeout=10
                )
                return re.findall(r"^\s+(\S+)", out, re.MULTILINE)
        except Exception as e:
            log.error(f"wifi_listele: {e}")
        return []

    # ── Ekran görüntüsü ─────────────────────────────────────────

    def ekran_goruntusu_al(self, dosya_adi: str = None) -> Optional[Path]:
        if dosya_adi is None:
            dosya_adi = f"ekran_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        yol = SCREENSHOT_DIR / dosya_adi
        if PIL_OK:
            try:
                img = ImageGrab.grab()
                img.save(str(yol))
                return yol
            except Exception as e:
                log.error(f"PIL screenshot: {e}")
        if PYAUTOGUI_OK:
            try:
                img = pyautogui.screenshot()
                img.save(str(yol))
                return yol
            except Exception as e:
                log.error(f"pyautogui screenshot: {e}")
        # Linux fallback
        if IS_LINUX:
            try:
                subprocess.run(["scrot", str(yol)], timeout=10)
                if yol.exists():
                    return yol
            except Exception:
                pass
        return None

    # ── Pano ────────────────────────────────────────────────────

    def panodan_oku(self) -> str:
        if PYPERCLIP_OK:
            try:
                return pyperclip.paste()
            except Exception:
                pass
        return ""

    def panoya_yaz(self, metin: str) -> bool:
        if PYPERCLIP_OK:
            try:
                pyperclip.copy(metin)
                return True
            except Exception:
                pass
        return False

    # ── Güç yönetimi (cross-platform) ───────────────────────────

    def uyku_moduna_al(self) -> bool:
        try:
            if IS_WINDOWS:
                subprocess.Popen(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"])
            elif IS_MAC:
                subprocess.Popen(["pmset", "sleepnow"])
            else:
                subprocess.Popen(["systemctl", "suspend"])
            return True
        except Exception:
            return False

    def ekrani_kilitle(self) -> bool:
        try:
            if IS_WINDOWS and CTYPES_OK:
                import ctypes
                ctypes.windll.user32.LockWorkStation()
            elif IS_MAC:
                subprocess.Popen(
                    ["/System/Library/CoreServices/Menu Extras/User.menu/Contents/Resources/CGSession",
                     "-suspend"]
                )
            else:
                subprocess.Popen(["loginctl", "lock-session"])
            return True
        except Exception:
            return False

    def islemleri_listele(self, filtre: str = None) -> List[Dict]:
        islemler = []
        if PSUTIL_OK:
            try:
                for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
                    try:
                        bilgi = proc.info
                        if filtre and filtre.lower() not in bilgi["name"].lower():
                            continue
                        islemler.append({
                            "pid":  bilgi["pid"],
                            "isim": bilgi["name"],
                            "cpu":  round(bilgi["cpu_percent"], 1),
                            "ram":  round(bilgi["memory_percent"], 1)
                        })
                    except Exception:
                        pass
            except Exception:
                pass
        islemler.sort(key=lambda x: x["cpu"], reverse=True)
        return islemler[:20]

    def islemi_sonlandir(self, isim_veya_pid) -> Tuple[bool, str]:
        if PSUTIL_OK:
            try:
                if isinstance(isim_veya_pid, int):
                    psutil.Process(isim_veya_pid).terminate()
                    return True, f"PID {isim_veya_pid} sonlandırıldı."
                sayac = 0
                for proc in psutil.process_iter(["pid", "name"]):
                    if isim_veya_pid.lower() in proc.info["name"].lower():
                        proc.terminate()
                        sayac += 1
                return (True, f"{sayac} işlem sonlandırıldı.") if sayac else (False, "Bulunamadı.")
            except Exception as e:
                return False, str(e)
        return False, "psutil yüklü değil."


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 10: UYGULAMA YÖNETİMİ (CROSS-PLATFORM)
# ═══════════════════════════════════════════════════════════════

class UygulamaYoneticisi:
    """Cross-platform uygulama başlatma ve kapatma."""

    # Ortak uygulama isimleri → platform-bağımsız komutlar
    BILINEN_UYGULAMALAR: Dict[str, Dict[str, str]] = {
        "not defteri":      {"windows": "notepad.exe",    "linux": "gedit",          "darwin": "open -a TextEdit"},
        "notepad":          {"windows": "notepad.exe",    "linux": "gedit",          "darwin": "open -a TextEdit"},
        "hesap makinesi":   {"windows": "calc.exe",       "linux": "gnome-calculator","darwin": "open -a Calculator"},
        "dosya gezgini":    {"windows": "explorer.exe",   "linux": "nautilus",       "darwin": "open"},
        "görev yöneticisi": {"windows": "taskmgr.exe",    "linux": "gnome-system-monitor","darwin": "open -a 'Activity Monitor'"},
        "terminal":         {"windows": "cmd.exe",        "linux": "gnome-terminal", "darwin": "open -a Terminal"},
        "cmd":              {"windows": "cmd.exe",        "linux": "bash",           "darwin": "bash"},
        "chrome":           {"windows": "chrome.exe",     "linux": "google-chrome",  "darwin": "open -a 'Google Chrome'"},
        "firefox":          {"windows": "firefox.exe",    "linux": "firefox",        "darwin": "open -a Firefox"},
        "edge":             {"windows": "msedge.exe",     "linux": "microsoft-edge", "darwin": "open -a 'Microsoft Edge'"},
        "spotify":          {"windows": "Spotify.exe",    "linux": "spotify",        "darwin": "open -a Spotify"},
        "discord":          {"windows": "Discord.exe",    "linux": "discord",        "darwin": "open -a Discord"},
        "vscode":           {"windows": "Code.exe",       "linux": "code",           "darwin": "open -a 'Visual Studio Code'"},
        "visual studio code": {"windows": "Code.exe",     "linux": "code",           "darwin": "open -a 'Visual Studio Code'"},
        "vlc":              {"windows": "vlc.exe",        "linux": "vlc",            "darwin": "open -a VLC"},
        "gimp":             {"windows": "gimp.exe",       "linux": "gimp",           "darwin": "open -a GIMP"},
        "telegram":         {"windows": "Telegram.exe",   "linux": "telegram-desktop","darwin": "open -a Telegram"},
        "whatsapp":         {"windows": "WhatsApp.exe",   "linux": "whatsapp-desktop","darwin": "open -a WhatsApp"},
        "zoom":             {"windows": "Zoom.exe",       "linux": "zoom",           "darwin": "open -a zoom.us"},
    }

    def __init__(self, db: ArslanDatabase):
        self.db = db
        self._platform_key = PLATFORM.lower()  # "windows", "linux", "darwin"

    def _uygulama_komutu(self, isim: str) -> Optional[str]:
        """Platform'a uygun komut döndür."""
        eslesme = AkilliBulucu.en_iyi_eslesme(isim.lower(), list(self.BILINEN_UYGULAMALAR.keys()), esik=0.55)
        if eslesme:
            komutlar = self.BILINEN_UYGULAMALAR[eslesme[0]]
            return komutlar.get(self._platform_key) or komutlar.get("linux")
        return None

    def uygulama_ac(self, isim: str, parametreler: List[str] = None) -> Tuple[bool, str]:
        komut = self._uygulama_komutu(isim)
        if komut:
            try:
                tam_komut = komut.split() + (parametreler or [])
                subprocess.Popen(tam_komut, shell=IS_WINDOWS)
                return True, f"'{isim}' açılıyor."
            except Exception as e:
                log.error(f"Uygulama açma: {e}")

        # Sistem genelinde arama
        yol = shutil.which(isim)
        if yol:
            try:
                subprocess.Popen([yol] + (parametreler or []))
                return True, f"'{isim}' açılıyor."
            except Exception as e:
                return False, str(e)

        # OS-level open (macOS/Linux)
        if not IS_WINDOWS:
            try:
                subprocess.Popen(["xdg-open" if IS_LINUX else "open", isim])
                return True, f"'{isim}' açılıyor."
            except Exception:
                pass

        return False, f"'{isim}' bulunamadı."

    def uygulama_kapat(self, isim: str) -> Tuple[bool, str]:
        if PSUTIL_OK:
            try:
                kapatilan = []
                for proc in psutil.process_iter(["pid", "name"]):
                    oran = AkilliBulucu.benzerlik(isim, proc.info["name"].replace(".exe", ""))
                    if oran > 0.6:
                        proc.terminate()
                        kapatilan.append(proc.info["name"])
                if kapatilan:
                    return True, f"'{', '.join(kapatilan)}' kapatıldı."
            except Exception as e:
                log.error(f"uygulama_kapat: {e}")
        if IS_WINDOWS:
            subprocess.run(["taskkill", "/F", "/IM", f"{isim}.exe"], capture_output=True)
        else:
            subprocess.run(["pkill", "-f", isim], capture_output=True)
        return True, f"'{isim}' kapatılıyor."

    def tarayici_ac(self, url: str = None, arama: str = None) -> bool:
        if arama and not url:
            url = f"https://www.google.com/search?q={urllib.parse.quote(arama)}"
        elif not url:
            url = "https://www.google.com"
        try:
            webbrowser.open(url)
            return True
        except Exception:
            return False


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 11: MEDYA KONTROLÜ (CROSS-PLATFORM)
# ═══════════════════════════════════════════════════════════════

class MedyaKontrol:
    """Cross-platform medya kontrolü."""

    def _medya_tus_gonder_windows(self, tus_kodu: int):
        if not IS_WINDOWS or not CTYPES_OK:
            return False
        try:
            import ctypes
            KEYEVENTF_EXTENDEDKEY = 0x1
            KEYEVENTF_KEYUP       = 0x2
            ctypes.windll.user32.keybd_event(tus_kodu, 0, KEYEVENTF_EXTENDEDKEY, 0)
            time.sleep(0.05)
            ctypes.windll.user32.keybd_event(tus_kodu, 0, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0)
            return True
        except Exception:
            return False

    def _xdotool(self, tus: str) -> bool:
        try:
            subprocess.run(["xdotool", "key", tus], capture_output=True, timeout=3)
            return True
        except Exception:
            return False

    def oynat_durdur(self) -> bool:
        if IS_WINDOWS:
            return self._medya_tus_gonder_windows(0xB3)
        if IS_LINUX:
            return self._xdotool("XF86AudioPlay")
        if IS_MAC:
            try:
                subprocess.run(["osascript", "-e",
                                "tell application \"System Events\" to key code 16 using command down"],
                               capture_output=True)
                return True
            except Exception:
                return False
        return False

    def sonraki(self) -> bool:
        if IS_WINDOWS:
            return self._medya_tus_gonder_windows(0xB0)
        return self._xdotool("XF86AudioNext")

    def onceki(self) -> bool:
        if IS_WINDOWS:
            return self._medya_tus_gonder_windows(0xB1)
        return self._xdotool("XF86AudioPrev")

    def youtube_ara(self, arama: str) -> bool:
        url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(arama)}"
        try:
            webbrowser.open(url)
            return True
        except Exception:
            return False


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 12: ZAMANLAYICI VE ALARM
# ═══════════════════════════════════════════════════════════════

class ZamanlayiciSistemi:
    def __init__(self, db: ArslanDatabase, ses_cikis: SesCikis):
        self.db   = db
        self.ses  = ses_cikis
        self.aktif_zamanlayicilar: Dict[str, Timer] = {}
        self._calisiyor = True
        threading.Thread(target=self._hatirlatici_kontrol, daemon=True).start()

    def _hatirlatici_kontrol(self):
        while self._calisiyor:
            try:
                simdi = datetime.datetime.now()
                for hat in self.db.aktif_hatirlaticilar():
                    try:
                        hat_zamani = datetime.datetime.fromisoformat(hat["zaman"])
                        if abs((simdi - hat_zamani).total_seconds()) < 30:
                            self.ses.konus(f"Hatırlatıcı: {hat['mesaj']}")
                            if hat["tekrar"] == "bir_kez":
                                with self.db.lock:
                                    self.db.conn.execute(
                                        "UPDATE hatirlaticilar SET aktif=0 WHERE id=?", (hat["id"],)
                                    )
                                    self.db.conn.commit()
                    except Exception:
                        pass
            except Exception:
                pass
            time.sleep(15)

    def zamanlayici_kur(self, sure_saniye: int, mesaj: str = None) -> str:
        tid = f"t_{int(time.time())}"
        if mesaj is None:
            sure_metin = f"{sure_saniye // 60} dakika" if sure_saniye >= 60 else f"{sure_saniye} saniye"
            mesaj = f"{sure_metin}lik zamanlayıcı doldu!"

        def callback():
            self.ses.konus(mesaj)
            self.aktif_zamanlayicilar.pop(tid, None)

        t = Timer(sure_saniye, callback)
        t.daemon = True
        t.start()
        self.aktif_zamanlayicilar[tid] = t
        return tid

    def alarm_kur(self, saat: str, mesaj: str = "Alarm!") -> bool:
        try:
            parcalar = saat.split(":")
            now    = datetime.datetime.now()
            hedef  = now.replace(hour=int(parcalar[0]), minute=int(parcalar[1]),
                                  second=0, microsecond=0)
            if hedef < now:
                hedef += datetime.timedelta(days=1)
            self.db.hatirlatici_ekle(mesaj, hedef.isoformat())
            return True
        except Exception as e:
            log.error(f"alarm_kur: {e}")
            return False

    @staticmethod
    def sure_parcala(metin: str) -> int:
        metin  = metin.lower()
        toplam = 0
        for kalip, carpan in [(r"(\d+)\s*saat", 3600), (r"(\d+)\s*dakika", 60), (r"(\d+)\s*saniye", 1)]:
            m = re.search(kalip, metin)
            if m:
                toplam += int(m.group(1)) * carpan
        if toplam == 0:
            m = re.search(r"(\d+)", metin)
            if m:
                toplam = int(m.group(1))
        return toplam

    def kapat(self):
        self._calisiyor = False
        for t in self.aktif_zamanlayicilar.values():
            t.cancel()


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 13: HAVA DURUMU
# ═══════════════════════════════════════════════════════════════

class HavaDurumu:
    def __init__(self, api_key: str = ""):
        self.api_key   = api_key
        self._cache    = {}
        self._cache_sure = 1800

    def hava_al(self, sehir: str = "Istanbul") -> Dict[str, Any]:
        simdi = time.time()
        if sehir in self._cache:
            veri, zaman = self._cache[sehir]
            if simdi - zaman < self._cache_sure:
                return veri
        veri = self._wttr_al(sehir)
        self._cache[sehir] = (veri, simdi)
        return veri

    def _wttr_al(self, sehir: str) -> Dict[str, Any]:
        try:
            url = f"https://wttr.in/{urllib.parse.quote(sehir)}?format=j1"
            req = urllib.request.Request(url, headers={"User-Agent": "ArslanBot/3.1"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                veri = json.loads(resp.read().decode())
            guncel = veri["current_condition"][0]
            return {
                "sehir":     sehir,
                "sicaklik":  int(guncel["temp_C"]),
                "hissedilen": int(guncel["FeelsLikeC"]),
                "nem":       int(guncel["humidity"]),
                "durum":     guncel["weatherDesc"][0]["value"],
                "ruzgar":    int(guncel["windspeedKmph"]),
            }
        except Exception as e:
            log.error(f"wttr: {e}")
            return {"hata": "Hava durumu alınamadı.", "sehir": sehir}

    def hava_metni_olustur(self, veri: Dict) -> str:
        if "hata" in veri:
            return veri["hata"]
        return (
            f"{veri.get('sehir', '?')} için hava: "
            f"{veri.get('sicaklik', '?')} derece, {veri.get('durum', '?')}. "
            f"Hissedilen {veri.get('hissedilen', '?')} derece, "
            f"nem yüzde {veri.get('nem', '?')}."
        )


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 14: HABER SERVİSİ
# ═══════════════════════════════════════════════════════════════

class HaberServisi:
    RSS_KAYNAKLARI = {
        "haberler":  "https://www.hurriyet.com.tr/rss/gundem",
        "teknoloji": "https://shiftdelete.net/feed",
        "ekonomi":   "https://www.hurriyet.com.tr/rss/ekonomi",
        "spor":      "https://www.hurriyet.com.tr/rss/spor",
        "dunya":     "https://www.hurriyet.com.tr/rss/dunya",
        "bbc":       "https://feeds.bbci.co.uk/turkce/rss.xml",
    }

    def __init__(self):
        self._cache = {}
        self._cache_sure = 1800

    def haberleri_al(self, kategori: str = "haberler", sayi: int = 5) -> List[Dict]:
        simdi     = time.time()
        cache_key = f"{kategori}_{sayi}"
        if cache_key in self._cache:
            veri, zaman = self._cache[cache_key]
            if simdi - zaman < self._cache_sure:
                return veri
        eslesme = AkilliBulucu.en_iyi_eslesme(kategori.lower(), list(self.RSS_KAYNAKLARI.keys()))
        rss_url = self.RSS_KAYNAKLARI[eslesme[0]] if eslesme else self.RSS_KAYNAKLARI["haberler"]
        haberler = self._rss_oku(rss_url, sayi)
        self._cache[cache_key] = (haberler, simdi)
        return haberler

    def _rss_oku(self, url: str, sayi: int = 5) -> List[Dict]:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "ArslanBot/3.1"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                icerik = resp.read().decode("utf-8", errors="replace")
            root    = ET.fromstring(icerik)
            channel = root.find("channel")
            items   = channel.findall("item") if channel else root.findall(".//item")
            haberler = []
            for item in items[:sayi]:
                baslik    = item.findtext("title", "").strip()
                aciklama  = re.sub(r"<[^>]+>", "", item.findtext("description", ""))[:200]
                haberler.append({"baslik": baslik, "aciklama": aciklama})
            return haberler
        except Exception as e:
            log.error(f"RSS: {e}")
            return []

    def haber_ozeti_olustur(self, haberler: List[Dict]) -> str:
        if not haberler:
            return "Haberler alınamadı."
        return "Son haberler: " + ". ".join(f"{i+1}. {h['baslik']}" for i, h in enumerate(haberler))


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 15: GÜVENLİ HESAP MAKİNESİ
# ═══════════════════════════════════════════════════════════════

class HesapMakinesi:
    """
    Güvenli matematik hesaplama motoru.
    eval() yerine AST tabanlı değerlendirici kullanır.
    """

    _IZINLI_DUGUMLER = (
        ast.Expression, ast.BinOp, ast.UnaryOp, ast.Num, ast.Constant,
        ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod,
        ast.Pow, ast.USub, ast.UAdd,
    )

    _OPERATORLER = {
        ast.Add:      operator.add,
        ast.Sub:      operator.sub,
        ast.Mult:     operator.mul,
        ast.Div:      operator.truediv,
        ast.FloorDiv: operator.floordiv,
        ast.Mod:      operator.mod,
        ast.Pow:      operator.pow,
        ast.USub:     operator.neg,
        ast.UAdd:     operator.pos,
    }

    _FONKSIYONLAR = {
        "sqrt": math.sqrt, "sin": math.sin, "cos": math.cos, "tan": math.tan,
        "log":  math.log,  "log10": math.log10, "abs": abs, "round": round,
        "ceil": math.ceil, "floor": math.floor,
    }

    def _degerlendir(self, dugum) -> float:
        if isinstance(dugum, ast.Expression):
            return self._degerlendir(dugum.body)
        if isinstance(dugum, ast.Constant) and isinstance(dugum.value, (int, float)):
            return float(dugum.value)
        if isinstance(dugum, ast.Num):  # Python 3.7 compat
            return float(dugum.n)
        if isinstance(dugum, ast.BinOp):
            sol   = self._degerlendir(dugum.left)
            sag   = self._degerlendir(dugum.right)
            op_fn = self._OPERATORLER.get(type(dugum.op))
            if op_fn is None:
                raise ValueError(f"Desteklenmeyen operatör: {type(dugum.op)}")
            return op_fn(sol, sag)
        if isinstance(dugum, ast.UnaryOp):
            operand = self._degerlendir(dugum.operand)
            op_fn   = self._OPERATORLER.get(type(dugum.op))
            if op_fn is None:
                raise ValueError(f"Desteklenmeyen unary: {type(dugum.op)}")
            return op_fn(operand)
        if isinstance(dugum, ast.Call):
            isim = getattr(dugum.func, "id", None)
            if isim in self._FONKSIYONLAR and len(dugum.args) <= 2:
                arglar = [self._degerlendir(a) for a in dugum.args]
                return self._FONKSIYONLAR[isim](*arglar)
        raise ValueError(f"Desteklenmeyen ifade: {ast.dump(dugum)}")

    def hesapla(self, ifade: str) -> Tuple[bool, str]:
        ifade = (ifade.strip()
                 .replace(",", ".").replace("×", "*").replace("÷", "/")
                 .replace("^", "**").replace("kare kök", "sqrt")
                 .replace("karekök", "sqrt")
                 .replace("pi", str(math.pi)))
        # Kelime → rakam
        for kelime, rakam in [("iki", "2"), ("üç", "3"), ("dört", "4"), ("beş", "5"),
                               ("altı", "6"), ("yedi", "7"), ("sekiz", "8"),
                               ("dokuz", "9"), ("on", "10"), ("yüz", "100"), ("bin", "1000")]:
            ifade = ifade.replace(kelime, rakam)
        try:
            agac   = ast.parse(ifade, mode="eval")
            sonuc  = self._degerlendir(agac)
            if isinstance(sonuc, float) and sonuc.is_integer():
                return True, str(int(sonuc))
            return True, str(round(sonuc, 10))
        except ZeroDivisionError:
            return False, "Sıfıra bölünemez."
        except Exception as e:
            return False, f"Hesaplama hatası: {e}"

    def donustur(self, deger: float, kaynak_birim: str, hedef_birim: str) -> Tuple[bool, str]:
        k = kaynak_birim.lower().strip()
        h = hedef_birim.lower().strip()
        # Sıcaklık
        if k in ["c", "celsius", "santigrat"] and h in ["f", "fahrenheit"]:
            return True, f"{deger}°C = {round(deger * 9/5 + 32, 2)}°F"
        if k in ["f", "fahrenheit"] and h in ["c", "celsius", "santigrat"]:
            return True, f"{deger}°F = {round((deger - 32) * 5/9, 2)}°C"
        if k in ["c", "celsius"] and h in ["k", "kelvin"]:
            return True, f"{deger}°C = {round(deger + 273.15, 2)}K"
        # Uzunluk (metreye)
        uzunluk = {"m": 1, "cm": 0.01, "mm": 0.001, "km": 1000,
                   "inc": 0.0254, "feet": 0.3048, "mil": 1609.344}
        if k in uzunluk and h in uzunluk:
            sonuc = deger * uzunluk[k] / uzunluk[h]
            return True, f"{deger} {kaynak_birim} = {round(sonuc, 6)} {hedef_birim}"
        # Ağırlık (kilograma)
        agirlik = {"kg": 1, "g": 0.001, "mg": 0.000001, "ton": 1000,
                   "libre": 0.453592, "ons": 0.0283495}
        if k in agirlik and h in agirlik:
            sonuc = deger * agirlik[k] / agirlik[h]
            return True, f"{deger} {kaynak_birim} = {round(sonuc, 6)} {hedef_birim}"
        return False, f"'{kaynak_birim}' → '{hedef_birim}' dönüşümü desteklenmiyor."


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 16: E-POSTA YÖNETİMİ
# ═══════════════════════════════════════════════════════════════

class EpostaYoneticisi:
    """IMAP/SMTP e-posta yönetimi (şifre .env'den okunur)."""

    def __init__(self, db: ArslanDatabase):
        self.db           = db
        self.smtp_host    = os.environ.get("EMAIL_SMTP_HOST",    db.tercih_oku("smtp_host",  "smtp.gmail.com"))
        self.smtp_port    = int(os.environ.get("EMAIL_SMTP_PORT", db.tercih_oku("smtp_port", "587")))
        self.imap_host    = os.environ.get("EMAIL_IMAP_HOST",    db.tercih_oku("imap_host",  "imap.gmail.com"))
        self.email_adresi = os.environ.get("EMAIL_ADDRESS",      db.tercih_oku("email_adresi", ""))
        self.email_sifre  = os.environ.get("EMAIL_PASSWORD",     "")  # .env'den al, DB'ye KAYDETME

    def eposta_gonder(self, alici: str, konu: str, icerik: str) -> Tuple[bool, str]:
        if not self.email_adresi or not self.email_sifre:
            return False, "E-posta hesabı yapılandırılmamış. .env dosyasına EMAIL_ADDRESS ve EMAIL_PASSWORD ekleyin."
        try:
            msg             = email.mime.multipart.MIMEMultipart()
            msg["From"]     = self.email_adresi
            msg["To"]       = alici
            msg["Subject"]  = konu
            msg.attach(email.mime.text.MIMEText(icerik, "plain", "utf-8"))
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as smtp:
                smtp.starttls()
                smtp.login(self.email_adresi, self.email_sifre)
                smtp.send_message(msg)
            return True, f"E-posta '{alici}' adresine gönderildi."
        except Exception as e:
            return False, str(e)

    def epostalari_oku(self, sayi: int = 5) -> List[Dict]:
        if not self.email_adresi or not self.email_sifre:
            return []
        try:
            imap = imaplib.IMAP4_SSL(self.imap_host)
            imap.login(self.email_adresi, self.email_sifre)
            imap.select("INBOX")
            _, mesajlar = imap.search(None, "ALL")
            mesaj_idleri = mesajlar[0].split()[-sayi:]
            epostalar    = []
            for mid in reversed(mesaj_idleri):
                _, veri = imap.fetch(mid, "(RFC822)")
                msg     = email.message_from_bytes(veri[0][1])
                gonderen = msg.get("From", "")
                konu_raw = msg.get("Subject", "")
                konu_list = decode_header(konu_raw)
                konu      = "".join(
                    p.decode(enc or "utf-8", errors="replace") if isinstance(p, bytes) else p
                    for p, enc in konu_list
                )
                epostalar.append({"gonderen": gonderen, "konu": konu})
            imap.logout()
            return epostalar
        except Exception as e:
            log.error(f"epostalari_oku: {e}")
            return []

    def eposta_ozeti_olustur(self, epostalar: List[Dict]) -> str:
        if not epostalar:
            return "Gelen kutusu boş veya erişilemiyor."
        return f"Son {len(epostalar)} e-posta: " + ". ".join(
            f"{i+1}. {ep['gonderen']} — {ep['konu']}" for i, ep in enumerate(epostalar)
        )


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 17: YAPAY ZEKA BEYNİ
# ═══════════════════════════════════════════════════════════════

class ArslanBeyin:
    """Groq LLM tabanlı yapay zeka düşünce motoru."""

    SISTEM_MESAJI = (
        f"Sen {ASSISTANT_NAME}'sın. {OWNER_NAME} için geliştirilmiş bir yapay zeka asistanısın. "
        "Çok kısa, net ve profesyonel cevaplar ver. Jarvis gibi. "
        "Maksimum 1-2 kısa cümle. Gereksiz açıklama yapma."
    )

    def __init__(self, groq_client, db: ArslanDatabase):
        self.groq      = groq_client
        self.db        = db
        self.oturum_id = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    def dusun(self, soru: str, ekstra_baglam: str = None) -> str:
        if not GROQ_OK or not self.groq:
            return "Yapay zeka bağlantısı yok."

        gecmis  = self.db.son_konusmalar(MAX_HISTORY, self.oturum_id)
        sistem  = self.SISTEM_MESAJI
        if ekstra_baglam:
            sistem += f"\n\nEK BAĞLAM:\n{ekstra_baglam}"

        mesajlar = [{"role": "system", "content": sistem}] + gecmis
        mesajlar.append({"role": "user", "content": soru})

        try:
            completion = self.groq.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=mesajlar,
                max_tokens=80,
                temperature=0.4,
                top_p=0.9
            )
            cevap = completion.choices[0].message.content.strip()
            self.db.konusma_ekle("user",      soru,  self.oturum_id)
            self.db.konusma_ekle("assistant", cevap, self.oturum_id)
            return cevap
        except Exception as e:
            log.error(f"LLM: {e}")
            return "Düşünce motorunda geçici sorun."


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 18: KOMUT İŞLEME MOTORU
# ═══════════════════════════════════════════════════════════════

class KomutMotoru:
    """Ana komut işleme ve yönlendirme sistemi."""

    def __init__(self, db, dosya, sistem, uygulama, medya, zamanlayici,
                 hava, haber, hesap, eposta, beyin, ses):
        self.db          = db
        self.dosya       = dosya
        self.sistem      = sistem
        self.uygulama    = uygulama
        self.medya       = medya
        self.zamanlayici = zamanlayici
        self.hava        = hava
        self.haber       = haber
        self.hesap       = hesap
        self.eposta      = eposta
        self.beyin       = beyin
        self.ses         = ses

    def isle(self, komut: str) -> str:
        if not komut or len(komut.strip()) < 2:
            return ""

        m      = komut.lower().strip()
        analiz = AkilliBulucu.komut_anlat(komut)
        log.info(f"Komut: {komut}")

        # ── Kimlik / yardım ──────────────────────────────────────
        if any(k in m for k in ["kimsin", "neler yapabilirsin", "yardım", "özellikler"]):
            return (f"Ben {ASSISTANT_NAME}, {OWNER_NAME}'nin yapay zeka asistanıyım. "
                    f"Dosya yönetimi, sistem kontrolü, uygulama açma/kapama, "
                    f"hava durumu, haber, zamanlayıcı, hesaplama ve çok daha fazlasını yapabilirim.")

        if "versiyon" in m or "sürüm" in m:
            return f"{ASSISTANT_NAME} versiyon {VERSION}."

        # ── Selamlama ─────────────────────────────────────────────
        if any(k in m for k in ["merhaba", "selam", "günaydın", "iyi günler", "hey"]):
            saat = datetime.datetime.now().hour
            if 5 <= saat < 12:  return f"Günaydın {OWNER_NAME}! Nasıl yardımcı olabilirim?"
            if 12 <= saat < 17: return f"İyi öğleden sonralar {OWNER_NAME}! Emredersiniz."
            if 17 <= saat < 21: return f"İyi akşamlar {OWNER_NAME}! Söyleyin."
            return f"İyi geceler {OWNER_NAME}! Emredersiniz."

        # ── YouTube / müzik ───────────────────────────────────────
        es_kapat = ["durdur", "kapat", "sonlandır", "paus"]
        if any(k in m for k in ["youtube", "müzik", "şarkı", "çal", "oynat"]) \
                and not any(k in m for k in es_kapat):
            arama = (m.replace("youtube", "").replace("aç", "").replace("oynat", "")
                      .replace("çal", "").replace("ara", "").replace("müzik", "")
                      .replace("şarkı", "").replace("bana", "").replace("dinlet", "")
                      .replace("gir", "").strip())
            if len(arama) > 2:
                self.medya.youtube_ara(arama)
                return "Açılıyor efendim."
            self.uygulama.tarayici_ac("https://www.youtube.com")
            return "Açılıyor efendim."

        # ── Dosya işlemleri ───────────────────────────────────────
        if analiz["dosya_mi"] and analiz["olustur_mu"]:
            return self._dosya_olustur_isle(komut, m)
        if analiz["klasor_mu"] and analiz["olustur_mu"]:
            return self._klasor_olustur_isle(komut, m)
        if analiz["listele_mi"]:
            return self._listele_isle(komut, m)
        if analiz["sil_mi"] and (analiz["dosya_mi"] or analiz["klasor_mu"]):
            return self._sil_isle(komut, m)
        if analiz["klasor_mu"] and analiz["ac_mi"]:
            return self._klasor_ac_isle(komut, m)
        if analiz["ac_mi"] and not analiz["klasor_mu"]:
            return self._ac_isle(komut, m)
        if analiz["kopyala_mi"]:
            return self._kopyala_isle(komut, m)
        if analiz["ara_mi"]:
            return self._ara_isle(komut, m)

        # ── İçerik sorgulama ─────────────────────────────────────
        if any(k in m for k in ["içeriği ne", "ne yazdın", "ne yazdı"]):
            return f"En son dosyaya şunu yazdım: {self.dosya.son_yazilan}" \
                   if self.dosya.son_yazilan else "Henüz bir dosyaya yazmadım."

        # ── Sistem kontrolü ───────────────────────────────────────
        if any(k in m for k in ["ses", "volume"]):
            return self._ses_isle(komut, m)
        if any(k in m for k in ["parlak", "brightness"]):
            return self._parlaklik_isle(komut, m)
        if any(k in m for k in ["pil", "batarya", "şarj"]):
            pil = self.sistem.pil_durumu()
            if pil["yuzde"] >= 0:
                durum = "şarj oluyor" if pil["sarj_oluyor"] else "şarjda değil"
                return f"Pil yüzde {pil['yuzde']}, {durum}. Kalan süre: {pil['kalan_sure']}."
            return "Pil bilgisi alınamadı."
        if any(k in m for k in ["cpu", "ram", "bellek", "işlemci", "sistem bilgi"]):
            return self._sistem_bilgisi_isle(m)
        if any(k in m for k in ["ekran görüntüsü", "screenshot", "ekranı yakala"]):
            yol = self.sistem.ekran_goruntusu_al()
            return f"Ekran görüntüsü alındı: {yol.name}" if yol else "Ekran görüntüsü alınamadı."
        if "kilitle" in m and "ekran" in m:
            return "Ekran kilitlendi." if self.sistem.ekrani_kilitle() else "Ekran kilitlenemedi."
        if any(k in m for k in ["uyku", "uyku modu"]) and any(k in m for k in ["al", "gir", "koy"]):
            return "Uyku moduna alınıyor." if self.sistem.uyku_moduna_al() else "Uyku modu başlatılamadı."
        if "wifi" in m and "listele" in m:
            aglar = self.sistem.wifi_listele()
            return f"WiFi ağları: {', '.join(aglar[:5])}" if aglar else "WiFi ağları bulunamadı."

        # ── Uygulama kapatma ─────────────────────────────────────
        if analiz["kapat_mi"] and not analiz["klasor_mu"] and not analiz["dosya_mi"]:
            return self._uygulama_kapat_isle(komut, m)

        # ── Medya ─────────────────────────────────────────────────
        if any(k in m for k in ["oynat", "devam et"]) and any(k in m for k in ["müzik", "medya"]):
            self.medya.oynat_durdur()
            return "Oynatılıyor."
        if "durdur" in m and any(k in m for k in ["müzik", "medya"]):
            self.medya.oynat_durdur()
            return "Duraklatıldı."
        if "sonraki şarkı" in m or "geç" in m:
            self.medya.sonraki()
            return "Sonraki parça."
        if "önceki şarkı" in m:
            self.medya.onceki()
            return "Önceki parça."

        # ── Zamanlayıcı / Alarm ───────────────────────────────────
        if any(k in m for k in ["zamanlayıcı", "timer", "sayaç"]):
            return self._zamanlayici_isle(komut, m)
        if any(k in m for k in ["alarm", "uyandır"]):
            return self._alarm_isle(komut, m)

        # ── Hava / Haberler ───────────────────────────────────────
        if any(k in m for k in ["hava", "hava durumu", "sıcaklık"]):
            return self._hava_isle(komut, m)
        if any(k in m for k in ["haber", "gündem", "son dakika"]):
            return self._haber_isle(m)

        # ── Hesaplama ─────────────────────────────────────────────
        if any(k in m for k in ["hesapla", "kaç", "çarp", "topla", "böl", "karekök", "sqrt"]) \
                or re.search(r"\d[\+\-\*\/]\d", m):
            return self._hesap_isle(komut, m)

        # ── Not ───────────────────────────────────────────────────
        if any(k in m for k in ["not al", "not ekle", "bunu kaydet"]):
            return self._not_isle(komut, m)

        # ── Hatırlatıcı ───────────────────────────────────────────
        if any(k in m for k in ["hatırlat", "remind"]):
            return self._hatirlatici_isle(komut, m)

        # ── E-posta ───────────────────────────────────────────────
        if any(k in m for k in ["eposta", "e-posta", "mail"]):
            return self._eposta_isle(komut, m)

        # ── Pano ─────────────────────────────────────────────────
        if any(k in m for k in ["pano", "clipboard"]):
            if any(k in m for k in ["oku", "ne var"]):
                icerik = self.sistem.panodan_oku()
                return f"Panoda: {icerik[:200]}" if icerik else "Pano boş."
            if "temizle" in m:
                self.sistem.panoya_yaz("")
                return "Pano temizlendi."

        # ── Tarih / Saat ─────────────────────────────────────────
        if any(k in m for k in ["saat", "tarih", "gün", "bugün ne"]):
            simdi   = datetime.datetime.now()
            gunler  = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
            if "saat" in m:
                return f"Saat {simdi.strftime('%H:%M')}."
            gun_adi = gunler[simdi.weekday()]
            return f"Bugün {gun_adi}, {simdi.strftime('%d %B %Y')}."

        # ── Genel AI cevabı ───────────────────────────────────────
        return self.beyin.dusun(komut)

    # ──────────────────────────────────────────────────────────
    # Yardımcı metotlar
    # ──────────────────────────────────────────────────────────

    def _dosya_olustur_isle(self, komut: str, m: str) -> str:
        isim_esle = re.search(r"(?:adı|adında|isimli|ismiyle)\s+(.+?)(?:\s+dosya|\s*$)", m)
        isim      = (isim_esle.group(1).strip() if isim_esle else
                     f"arslan_not_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}") + ".txt"
        icerik    = ""
        for ayiraci in ["içeriği", "içine", "içindeki"]:
            if ayiraci in m:
                icerik = komut.split(ayiraci, 1)[-1].strip()
                break
        if not icerik:
            icerik = f"{ASSISTANT_NAME} tarafından oluşturuldu — {datetime.datetime.now().strftime('%d/%m/%Y %H:%M')}"
        ok, sonuc = self.dosya.dosya_olustur(isim, icerik)
        if ok:
            self.db.komut_kaydet(komut, sonuc, True)
            return f"'{isim}' dosyası oluşturuldu."
        return f"Dosya oluşturulamadı: {sonuc}"

    def _klasor_olustur_isle(self, komut: str, m: str) -> str:
        isim = None
        for kalip in [
            r"(?:adlı|adında|isimli)\s+(.+?)(?:\s+klasör|\s*$)",
            r"(.+?)\s+(?:adlı|adında|isimli)\s+klasör",
            r"(.+?)\s+klasörü?\s+(?:oluştur|yarat|aç)",
        ]:
            esle = re.search(kalip, m)
            if esle:
                isim = esle.group(1).strip()
                break
        if not isim:
            isim = f"Arslan_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
        ok, sonuc = self.dosya.klasor_olustur(isim)
        return f"'{isim}' klasörü oluşturuldu." if ok else f"Klasör oluşturulamadı: {sonuc}"

    def _listele_isle(self, komut: str, m: str) -> str:
        hedef_klasor = None
        for kalip in [r"(.+?)\s+klasörü?ndeki", r"(.+?)\s+içindeki", r"(.+?)\s+klasörü?\s+içeri"]:
            esle = re.search(kalip, m)
            if esle:
                klasor_adi = esle.group(1).strip()
                bulunan    = self.dosya.klasor_ara_akilli(klasor_adi)
                if bulunan:
                    hedef_klasor = bulunan
                else:
                    tum_klasorler = [item.name for item in self.dosya.aktif_klasor.iterdir() if item.is_dir()]
                    oneriler      = AkilliBulucu.benzer_onerileri(klasor_adi, tum_klasorler)
                    if oneriler:
                        return f"'{klasor_adi}' bulunamadı. Bunu mu demek istediniz: {', '.join(oneriler)}?"
                    return f"'{klasor_adi}' klasörü bulunamadı."
                break

        klasorler, dosyalar = self.dosya.klasor_listele(hedef_klasor)
        if not klasorler and not dosyalar:
            return f"'{(hedef_klasor or self.dosya.aktif_klasor).name}' boş."

        parcalar = []
        if klasorler:
            parcalar.append(f"{len(klasorler)} klasör: {', '.join(k['isim'] for k in klasorler[:10])}")
        if dosyalar:
            parcalar.append(f"{len(dosyalar)} dosya: {', '.join(d['isim'] for d in dosyalar[:10])}")
        konum = (hedef_klasor or self.dosya.aktif_klasor).name
        return f"'{konum}' içinde " + "; ".join(parcalar) + "."

    def _sil_isle(self, komut: str, m: str) -> str:
        hedef_adi = None
        for kalip in [r"(.+?)\s+(?:dosyasını|klasörünü)\s+sil", r"sil\s+(.+)"]:
            esle = re.search(kalip, m)
            if esle:
                hedef_adi = esle.group(1).strip()
                break
        if hedef_adi:
            d = AkilliBulucu.dosya_bul(hedef_adi, self.dosya.aktif_klasor)
            if d:
                ok, msg = self.dosya.dosya_sil(d)
                return msg if ok else f"Silinemedi: {msg}"
            k = AkilliBulucu.klasor_bul(hedef_adi, self.dosya.aktif_klasor)
            if k:
                ok, msg = self.dosya.klasor_sil(k)
                return msg if ok else f"Silinemedi: {msg}"
        return "Silinecek öğe bulunamadı."

    def _klasor_ac_isle(self, komut: str, m: str) -> str:
        for kalip in [r"(.+?)\s+klasörü?nü\s+aç", r"aç\s+(.+?)\s+klasörü?", r"(.+?)\s+klasörü?\s+aç"]:
            esle = re.search(kalip, m)
            if esle:
                klasor_adi = esle.group(1).strip()
                bulunan    = self.dosya.klasor_ara_akilli(klasor_adi)
                if bulunan:
                    self.dosya.klasor_ac(bulunan)
                    self.dosya.aktif_klasor_degistir(bulunan)
                    return f"'{bulunan.name}' klasörü açıldı."
                tum_klasorler = [item.name for item in self.dosya.aktif_klasor.iterdir() if item.is_dir()]
                oneriler      = AkilliBulucu.benzer_onerileri(klasor_adi, tum_klasorler)
                if oneriler:
                    return f"'{klasor_adi}' bulunamadı. Şunları mı demek istediniz: {', '.join(oneriler)}?"
                return f"'{klasor_adi}' klasörü bulunamadı."
        return "Hangi klasörü açmamı istiyorsunuz?"

    def _ac_isle(self, komut: str, m: str) -> str:
        hedef = m
        for g in ["aç", "başlat", "çalıştır", "open", "ac"]:
            hedef = hedef.replace(g, "").strip()
        ok, mesaj = self.uygulama.uygulama_ac(hedef)
        if ok:
            return mesaj
        dosya = AkilliBulucu.dosya_bul(hedef, self.dosya.aktif_klasor)
        if dosya:
            try:
                if IS_WINDOWS:
                    os.startfile(str(dosya))
                elif IS_MAC:
                    subprocess.Popen(["open", str(dosya)])
                else:
                    subprocess.Popen(["xdg-open", str(dosya)])
                return f"'{dosya.name}' açılıyor."
            except Exception:
                pass
        return f"'{hedef}' açılamadı."

    def _uygulama_kapat_isle(self, komut: str, m: str) -> str:
        hedef = m
        for g in ["kapat", "durdur", "sonlandır"]:
            hedef = hedef.replace(g, "").strip()
        _, mesaj = self.uygulama.uygulama_kapat(hedef)
        return mesaj

    def _kopyala_isle(self, komut: str, m: str) -> str:
        for kalip in [r"(.+?)\s+(?:dosyasını)\s+(.+?)\s+(?:kopyala|taşı)"]:
            esle = re.search(kalip, m)
            if esle:
                kaynak = AkilliBulucu.dosya_bul(esle.group(1).strip(), self.dosya.aktif_klasor)
                hedef  = AkilliBulucu.klasor_bul(esle.group(2).strip(), self.dosya.aktif_klasor)
                if kaynak and hedef:
                    ok, msg = self.dosya.dosya_kopyala(kaynak, hedef / kaynak.name)
                    return msg
        return "Kopyalama için kaynak ve hedef belirleyemesem de detay verir misiniz?"

    def _ara_isle(self, komut: str, m: str) -> str:
        if any(k in m for k in ["web", "internet", "google"]):
            arama = m
            for g in ["ara", "web", "internet", "google"]:
                arama = arama.replace(g, "").strip()
            self.uygulama.tarayici_ac(arama=arama)
            return f"Google'da '{arama}' aranıyor."
        arama = m
        for g in ["ara", "bul", "nerede", "dosyayı", "dosya"]:
            arama = arama.replace(g, "").strip()
        dosyalar = self.dosya.dosya_ara(arama)
        if dosyalar:
            return f"Bulunanlar: {', '.join(d.name for d in dosyalar[:5])}"
        klasor = self.dosya.klasor_ara_akilli(arama)
        if klasor:
            return f"En yakın klasör: '{klasor.name}'"
        return f"'{arama}' için sonuç bulunamadı."

    def _ses_isle(self, komut: str, m: str) -> str:
        sayi = re.search(r"(\d+)", m)
        if sayi:
            seviye = int(sayi.group(1))
            if self.sistem.sistem_sesi_ayarla(seviye):
                return f"Ses yüzde {seviye} olarak ayarlandı."
        if any(k in m for k in ["arttır", "yükselt", "aç"]):
            mevcut = self.sistem.sistem_sesi_al()
            if mevcut >= 0:
                yeni = min(100, mevcut + 10)
                self.sistem.sistem_sesi_ayarla(yeni)
                return f"Ses yüzde {yeni}'e çıkarıldı."
        if any(k in m for k in ["azalt", "düşür", "kıs"]):
            mevcut = self.sistem.sistem_sesi_al()
            if mevcut >= 0:
                yeni = max(0, mevcut - 10)
                self.sistem.sistem_sesi_ayarla(yeni)
                return f"Ses yüzde {yeni}'e düşürüldü."
        if any(k in m for k in ["kapat", "sessiz", "mute"]):
            self.sistem.sistem_sessiz_ac_kapat()
            return "Sessiz mod değiştirildi."
        mevcut = self.sistem.sistem_sesi_al()
        return f"Ses şu an yüzde {mevcut}." if mevcut >= 0 else "Ses seviyesi alınamadı."

    def _parlaklik_isle(self, komut: str, m: str) -> str:
        sayi = re.search(r"(\d+)", m)
        if sayi:
            seviye = int(sayi.group(1))
            if self.sistem.parlaklik_ayarla(seviye):
                return f"Parlaklık yüzde {seviye} olarak ayarlandı."
        if any(k in m for k in ["arttır", "yükselt", "aç"]):
            mevcut = self.sistem.parlakligi_al()
            if mevcut >= 0:
                yeni = min(100, mevcut + 10)
                self.sistem.parlaklik_ayarla(yeni)
                return f"Parlaklık yüzde {yeni}'e çıkarıldı."
        if any(k in m for k in ["azalt", "düşür", "kıs"]):
            mevcut = self.sistem.parlakligi_al()
            if mevcut >= 0:
                yeni = max(0, mevcut - 10)
                self.sistem.parlaklik_ayarla(yeni)
                return f"Parlaklık yüzde {yeni}'e düşürüldü."
        mevcut = self.sistem.parlakligi_al()
        return f"Parlaklık şu an yüzde {mevcut}." if mevcut >= 0 else "Parlaklık bilgisi alınamadı."

    def _sistem_bilgisi_isle(self, m: str) -> str:
        bilgi   = self.sistem.sistem_bilgisi()
        parcalar = []
        if "cpu" in m or "işlemci" in m:
            parcalar.append(f"CPU yüzde {bilgi.get('cpu_yuzde', '?')}")
        if "ram" in m or "bellek" in m:
            parcalar.append(f"RAM yüzde {bilgi.get('ram_yuzde', '?')} ({bilgi.get('ram_kullanilan', '?')} / {bilgi.get('ram_toplam', '?')})")
        if "disk" in m:
            parcalar.append(f"Disk yüzde {bilgi.get('disk_yuzde', '?')}")
        if not parcalar:
            parcalar = [
                f"CPU yüzde {bilgi.get('cpu_yuzde', '?')}",
                f"RAM yüzde {bilgi.get('ram_yuzde', '?')}",
                f"Disk yüzde {bilgi.get('disk_yuzde', '?')}",
            ]
        return ". ".join(parcalar) + "."

    def _zamanlayici_isle(self, komut: str, m: str) -> str:
        sure = self.zamanlayici.sure_parcala(m)
        if sure > 0:
            sure_metin = (f"{sure//3600} saat" if sure >= 3600
                          else f"{sure//60} dakika" if sure >= 60
                          else f"{sure} saniye")
            self.zamanlayici.zamanlayici_kur(sure, f"{sure_metin}lik zamanlayıcı doldu {OWNER_NAME}!")
            return f"{sure_metin}lik zamanlayıcı kuruldu."
        return "Süre anlaşılamadı. 'X dakika zamanlayıcı kur' şeklinde söyleyin."

    def _alarm_isle(self, komut: str, m: str) -> str:
        esle = re.search(r"(\d{1,2})[:\.](\d{2})", m)
        if esle:
            saat_str = f"{esle.group(1)}:{esle.group(2)}"
            if self.zamanlayici.alarm_kur(saat_str, f"Alarm! Saat {saat_str}."):
                return f"Saat {saat_str} için alarm kuruldu."
        return "Alarm saati anlaşılamadı. 'X:XX için alarm kur' şeklinde söyleyin."

    def _hava_isle(self, komut: str, m: str) -> str:
        sehir = "Istanbul"
        esle  = re.search(r"(.+?)\s+(?:için|'de|'da)\s+hava", m)
        if esle:
            sehir = esle.group(1).strip()
        kayitli = self.db.hafiza_oku("hava_sehir")
        if kayitli:
            sehir = kayitli
        return self.hava.hava_metni_olustur(self.hava.hava_al(sehir))

    def _haber_isle(self, m: str) -> str:
        kategori = "haberler"
        for k in ["teknoloji", "spor", "ekonomi", "dunya", "bbc"]:
            if k in m:
                kategori = k
                break
        return self.haber.haber_ozeti_olustur(self.haber.haberleri_al(kategori))

    def _hesap_isle(self, komut: str, m: str) -> str:
        # Birim dönüşümü
        if any(k in m for k in ["celsius", "fahrenheit", "derece"]):
            sayi_esle = re.search(r"([\d\.]+)", m)
            if sayi_esle:
                sayi = float(sayi_esle.group(1))
                if "celsius" in m and "fahrenheit" in m:
                    ok, sonuc = self.hesap.donustur(sayi, "celsius", "fahrenheit")
                    return sonuc if ok else self.beyin.dusun(komut)
                if "fahrenheit" in m and "celsius" in m:
                    ok, sonuc = self.hesap.donustur(sayi, "fahrenheit", "celsius")
                    return sonuc if ok else self.beyin.dusun(komut)
        # Normal hesaplama
        ifade = m
        for g in ["hesapla", "kaç", "ne kadar", "sonucu", "ne eder"]:
            ifade = ifade.replace(g, "").strip()
        ok, sonuc = self.hesap.hesapla(ifade)
        return f"Sonuç: {sonuc}" if ok else self.beyin.dusun(komut)

    def _not_isle(self, komut: str, m: str) -> str:
        icerik = komut
        for g in ["not al", "not ekle", "bunu kaydet", "şunu yaz"]:
            icerik = icerik.replace(g, "").strip()
        if not icerik:
            return "Ne not almamı istiyorsunuz?"
        baslik = icerik[:30] + ("..." if len(icerik) > 30 else "")
        nid    = self.db.not_ekle(baslik, icerik)
        return f"Not alındı: '{baslik}'" if nid >= 0 else "Not alınamadı."

    def _hatirlatici_isle(self, komut: str, m: str) -> str:
        mesaj = komut
        for g in ["hatırlat", "remind", "saat", "beni"]:
            mesaj = mesaj.replace(g, "").strip()
        esle  = re.search(r"(\d{1,2})[:\.](\d{2})", m)
        if esle:
            saat_str = f"{esle.group(1)}:{esle.group(2)}"
            if self.zamanlayici.alarm_kur(saat_str, mesaj):
                return f"Saat {saat_str}'de hatırlatacağım."
        sure = self.zamanlayici.sure_parcala(m)
        if sure > 0:
            self.zamanlayici.zamanlayici_kur(sure, mesaj)
            return f"{sure} saniye sonra hatırlatacağım."
        return "Hatırlatıcı zamanı anlaşılamadı."

    def _eposta_isle(self, komut: str, m: str) -> str:
        if any(k in m for k in ["oku", "göster", "kontrol"]):
            return self.eposta.eposta_ozeti_olustur(self.eposta.epostalari_oku())
        return "E-posta için .env dosyasına EMAIL_ADDRESS ve EMAIL_PASSWORD ekleyin."


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 19: ANA SİSTEM
# ═══════════════════════════════════════════════════════════════

class ArslanSistemi:
    """Tüm modülleri bir araya getiren ana sistem."""

    def __init__(self):
        print("=" * 70)
        print(f"   {ASSISTANT_NAME} v{VERSION} başlatılıyor — Platform: {PLATFORM}")
        print("=" * 70)

        # Groq
        self.groq_client = None
        if GROQ_OK and GROQ_API_KEY:
            try:
                self.groq_client = Groq(api_key=GROQ_API_KEY)
                print("[OK] Groq API bağlantısı kuruldu.")
            except Exception as e:
                print(f"[HATA] Groq API: {e}")
        else:
            print("[UYARI] Groq API devre dışı (anahtar eksik veya kütüphane yüklü değil).")

        # Modüller
        self.db          = ArslanDatabase(MEMORY_DIR);     print("[OK] Veritabanı")
        self.ses         = SesCikis();                      print("[OK] TTS")
        self.ses_giris   = SesGiris(self.groq_client);     print("[OK] STT")
        self.dosya       = DosyaYoneticisi(self.db)
        self.sistem      = SistemKontrol(self.db)
        self.uygulama    = UygulamaYoneticisi(self.db)
        self.medya       = MedyaKontrol()
        self.hava        = HavaDurumu(WEATHER_API_KEY)
        self.haber       = HaberServisi()
        self.hesap       = HesapMakinesi()
        self.eposta      = EpostaYoneticisi(self.db)
        self.beyin       = ArslanBeyin(self.groq_client, self.db)
        self.zamanlayici = ZamanlayiciSistemi(self.db, self.ses)
        print("[OK] Tüm modüller yüklendi.")

        self.motor = KomutMotoru(
            self.db, self.dosya, self.sistem, self.uygulama,
            self.medya, self.zamanlayici, self.hava, self.haber,
            self.hesap, self.eposta, self.beyin, self.ses
        )
        print("[OK] Komut motoru hazır.")

        self.aktif     = True
        self.oturum_id = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

        # Önceki aktif klasörü yükle
        kayitli = self.db.hafiza_oku("aktif_klasor")
        if kayitli and Path(kayitli).exists():
            self.dosya.aktif_klasor_degistir(Path(kayitli))

        atexit.register(self._temizle)
        print(f"[OK] {ASSISTANT_NAME} hazır!")
        print("=" * 70)

    def _temizle(self):
        log.info("Sistem kapatılıyor...")
        try:
            self.zamanlayici.kapat()
            self.ses_giris.kapat()
            self.db.kapat()
        except Exception as e:
            log.error(f"Temizleme: {e}")

    def cevap_ver(self, komut: str) -> str:
        if not komut or len(komut.strip()) < 2:
            return ""
        try:
            return self.motor.isle(komut)
        except Exception as e:
            log.error(f"cevap_ver: {e}\n{traceback.format_exc()}")
            return "Bir hata oluştu, tekrar deneyin."

    def sesli_cevap_ver(self, komut: str):
        cevap = self.cevap_ver(komut)
        if cevap:
            self.ses.konus(cevap)
        return cevap

    def calis(self):
        """Sesli çalışma döngüsü."""
        self.ses.konus(f"Sistem hazır {OWNER_NAME}. '{ASSISTANT_NAME}' diye çağırın.")

        while self.aktif:
            try:
                print(f"\n[Bekleniyor — '{ASSISTANT_NAME}' deyin]", end="\r", flush=True)
                uyandi = self.ses_giris.pusuda_bekle()
                if not uyandi:
                    continue

                self.ses.konus("Emredin.")

                while self.aktif:
                    komut = self.ses_giris.dinle(max_sure=10.0)
                    if not komut:
                        break
                    if any(k in komut.lower() for k in SLEEP_WORDS):
                        self.ses.konus("Görüşürüz.")
                        break
                    self.sesli_cevap_ver(komut)

            except KeyboardInterrupt:
                print("\n[Çıkılıyor...]")
                self.ses.konus("Görüşürüz.")
                self.aktif = False
                break
            except Exception as e:
                log.error(f"Ana döngü: {e}")
                time.sleep(1)

    def klavye_modu(self):
        """Klavye girişli çalışma modu."""
        self.ses.konus(f"Merhaba {OWNER_NAME}! Klavye modundayım.")
        print("\n[Klavye Modu] Komut yazın. Çıkmak için 'çıkış' yazın.\n")

        while self.aktif:
            try:
                komut = input(f"[{OWNER_NAME}]: ").strip()
                if not komut:
                    continue
                if komut.lower() in ["çıkış", "exit", "quit", "q"]:
                    self.ses.konus("Görüşürüz.")
                    break
                self.sesli_cevap_ver(komut)
            except (KeyboardInterrupt, EOFError):
                self.ses.konus("Görüşürüz.")
                break

    def karistik_mod(self):
        """Hem sesli hem klavye girişini destekleyen mod."""
        self.ses.konus(f"Sistem hazır {OWNER_NAME}.")

        while self.aktif:
            try:
                klavye_kuyrugu = queue.Queue()
                ses_kuyrugu    = queue.Queue()

                def klavye_oku():
                    try:
                        girdi = input(f"\n[{OWNER_NAME}] (veya mikrofon): ")
                        klavye_kuyrugu.put(girdi)
                    except Exception:
                        pass

                def ses_bekle():
                    if self.ses_giris.pusuda_bekle():
                        ses_kuyrugu.put("UYANDI")

                threading.Thread(target=klavye_oku, daemon=True).start()
                threading.Thread(target=ses_bekle,  daemon=True).start()

                while True:
                    if not klavye_kuyrugu.empty():
                        komut = klavye_kuyrugu.get()
                        if komut.lower() in ["çıkış", "exit", "quit"]:
                            self.aktif = False
                        elif komut:
                            self.sesli_cevap_ver(komut)
                        break
                    if not ses_kuyrugu.empty():
                        ses_kuyrugu.get()
                        self.ses.konus("Emredin.")
                        while True:
                            komut = self.ses_giris.dinle()
                            if not komut:
                                break
                            if any(k in komut.lower() for k in SLEEP_WORDS):
                                self.ses.konus("Görüşürüz.")
                                break
                            self.sesli_cevap_ver(komut)
                        break
                    time.sleep(0.05)

            except KeyboardInterrupt:
                self.ses.konus("Görüşürüz.")
                self.aktif = False
                break
            except Exception as e:
                log.error(f"karistik_mod: {e}")
                time.sleep(1)


# ═══════════════════════════════════════════════════════════════
# BÖLÜM 20: BAŞLANGIÇ
# ═══════════════════════════════════════════════════════════════

def sistem_gereksinimleri_kontrol():
    eksikler = []
    uyarilar = []
    if not PYAUDIO_OK:   eksikler.append("pyaudio — pip install pyaudio")
    if not NUMPY_OK:     eksikler.append("numpy — pip install numpy")
    if not EDGE_TTS_OK:  eksikler.append("edge-tts — pip install edge-tts")
    if not PYGAME_OK:    eksikler.append("pygame — pip install pygame")
    if not GROQ_OK:      eksikler.append("groq — pip install groq")
    if not PSUTIL_OK:    uyarilar.append("psutil — pip install psutil")
    if not PYPERCLIP_OK: uyarilar.append("pyperclip — pip install pyperclip")
    if not SBC_OK:       uyarilar.append("screen-brightness-control — pip install screen-brightness-control")
    if not PYCAW_OK and IS_WINDOWS:
        uyarilar.append("pycaw — pip install pycaw (Windows ses kontrolü için)")
    if not PDF_OK:       uyarilar.append("pdfplumber — pip install pdfplumber")

    if eksikler:
        print("\n[!] EKSİK ZORUNLU KÜTÜPHANELER (ses özelliği için):")
        for e in eksikler:
            print(f"    • {e}")
    if uyarilar:
        print("\n[i] ÖNERİLEN (eksik ama çalışır):")
        for u in uyarilar:
            print(f"    • {u}")
    return len(eksikler) == 0


def main():
    import argparse
    parser = argparse.ArgumentParser(description=f"{ASSISTANT_NAME} AI Asistan v{VERSION}")
    parser.add_argument("--klavye",   action="store_true", help="Klavye modunda çalış")
    parser.add_argument("--karistik", action="store_true", help="Ses + klavye karışık mod")
    parser.add_argument("--kontrol",  action="store_true", help="Sistem gereksinimlerini kontrol et")
    parser.add_argument("--komut",    type=str,            help="Tek komut çalıştır ve çık")
    args = parser.parse_args()

    if args.kontrol:
        sistem_gereksinimleri_kontrol()
        return

    sistem_gereksinimleri_kontrol()

    arslan = ArslanSistemi()

    if args.komut:
        cevap = arslan.cevap_ver(args.komut)
        print(f"[{ASSISTANT_NAME}]: {cevap}")
        return

    if args.klavye:
        arslan.klavye_modu()
    elif args.karistik:
        arslan.karistik_mod()
    else:
        if PYAUDIO_OK and NUMPY_OK and GROQ_OK and GROQ_API_KEY:
            arslan.calis()
        else:
            print("[i] Ses eksik veya API anahtarı yok — klavye moduna geçiliyor.")
            arslan.klavye_modu()


if __name__ == "__main__":
    main()
